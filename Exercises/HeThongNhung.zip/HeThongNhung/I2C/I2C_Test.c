//MPU-6050
#include<wiringPiI2C.h>
#include<wiringPi.h>
#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<math.h>

int mpu;

void initMpu(void){
    //sample rate = 100Hz, enable DLPF
    wiringPiI2CWriteReg8(mpu, 0x19, 9);
    //DLPF fc = 94MHz
    wiringPiI2CWriteReg8(mpu, 0x1A, 0x02);
    //gyro FS +-500
    wiringPiI2CWriteReg8(mpu, 0x1B, 0x08);
    //accel FS +-8g
    wiringPiI2CWriteReg8(mpu, 0x1C, 0x10);
    //DRY interrupt enable
    wiringPiI2CWriteReg8(mpu, 0x38, 0x01);
    //clock source : gyroX
    wiringPiI2CWriteReg8(mpu, 0x68, 1);
}

int main(void){
    //setup I2C interface
    mpu = wiringPiSetup(0x68);
    //check connection
    if(wiringPiI2CReadReg8(mpu, 0x75)!= 0x68){
        printf("Connection fail. \n");
        exit(1);
    }
    //setup operational mode for MPU6050
    initMpu();
    //enable interrupt


    return 0;
}