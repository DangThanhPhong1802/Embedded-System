#include <wiringPi.h>
#include <wiringPiSPI.h>
#include <stdio.h>
#include <stdint.h>
#include <wiringPiI2C.h>
#include <time.h>
#define spi0 0
int i=0;
unsigned int dosang[10] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09};
unsigned int number[10] = {0b1111110, 0b0110000,0b1101101,0b1111001,0b0110011,0b1011011,0b1011111,0b1110000,0b1111111,0b1111011};
unsigned char font[][2] = {
  {'A',0b1110111},{'B',0b1111111},{'C',0b1001110},{'D',0b1111110},{'E',0b1001111},{'F',0b1000111},       
  {'G',0b1011110},{'H',0b0110111},{'I',0b0110000},{'J',0b0111100},{'L',0b0001110},{'N',0b1110110},       
  {'O',0b1111110},{'P',0b1100111},{'R',0b0000101},{'S',0b1011011},{'T',0b0001111},{'U',0b0111110},       
  {'Y',0b0100111},{'[',0b1001110},{']',0b1111000},{'_',0b0001000},{'a',0b1110111},{'b',0b0011111},       
  {'c',0b0001101},{'d',0b0111101},{'e',0b1001111},{'f',0b1000111},{'g',0b1011110},{'h',0b0010111},       
  {'i',0b0010000},{'j',0b0111100},{'l',0b0001110},{'n',0b0010101},{'o',0b1100011},{'p',0b1100111},       
  {'r',0b0000101},{'s',0b1011011},{'t',0b0001111},{'u',0b0011100},{'y',0b0100111},{'-',0b0000001},
  {' ',0b0000000},{'0',0b1111110},{'1',0b0110000},{'2',0b1101101},{'3',0b1111001},{'4',0b0110011},
  {'5',0b1011011},{'6',0b1011111},{'7',0b1110000},{'8',0b1111111},{'9',0b1111011},{'V',0b0111110},
  {'.',0b10000000},{'?',0b1100101},{'\0',0b0000000},};
unsigned int x,y,z,m,n;
int o=0,value,l=1;
time_t current_time;
char time_string[9];
int hour,min,sec;
struct tm * time_info;

typedef enum { false, true } bool;

void sendData(unsigned char address, unsigned char value)
{
	unsigned char data[2] ;//16bit
	data[0] = address; //Dia chi hexa de chon mode can thay doi(datasheet)
	data[1] = value;   //Chon cac tuy chon thay doi(datasheet)
	wiringPiSPIDataRW(0, data, 2); //Gui data gom 2 byte qua channel 0
	
}
void clr(void){
    for(int i=1;i<9;i++)
    {
        sendData(i,0x00);
    }
}

void tangGiamDoSang()
{
    value += l;
    
    if(value >= 9)
    {
        l = -l;
    }
    else if(value <= 0)
    {
        l = -l;
    }
    
}

void Init_7219(void)
{
	
	//set decode mode
	sendData(0x09, 0x00);
	//set intensity
	sendData(0x0A, 0x00);
	//set scan limit
	sendData(0x0B, 0x07);
	//set shutdown
	sendData(0x0C, 0x01);
	//set display test
	sendData(0x0F, 0x00);
	
}

uint8_t doctohex (uint8_t d)
{
    uint8_t h;
    h =(d/10 <<4)|(d%10 );
	return h;
}

int main(void)
{
	//Set up wiringPi
	int ds = wiringPiI2CSetup(0x68);
	wiringPiSetup();
	wiringPiSPISetup(spi0,20000000);
	Init_7219();
	clr();
	
	printf("Nhap thoi gian dung:");
	scanf("%d %d %d",&x,&y,&z);

	while(1){
		time_t T = time(NULL);
		struct tm tm = *localtime(&T);
		wiringPiI2CWriteReg8(ds,0x00,doctohex(tm.tm_sec));
		wiringPiI2CWriteReg8(ds,0x01,doctohex(tm.tm_min));
		wiringPiI2CWriteReg8(ds,0x02,doctohex(tm.tm_hour));
		// check ds3231 time

		unsigned int hh, mm, ss; 
		unsigned int chuc_gio,dv_gio,chuc_phut,dv_phut,chuc_giay,dv_giay;

		ss = wiringPiI2CReadReg8(ds, 0x00);
		mm = wiringPiI2CReadReg8(ds, 0x01);
		hh = wiringPiI2CReadReg8(ds, 0x02);
		m = hh | 0x00;
		n = mm | 0x00;
 		if((m>=x)&(n>=y))
		{
			tangGiamDoSang();
			sendData(0x0A, dosang[value]);
			delay(1000);
		}
		printf("ds3231 time is: %x:%x:%x \n",hh,mm,ss);
		chuc_gio = hh>>4 | 0x00;
		dv_gio = hh & 0x0f;
		chuc_phut = mm>>4 | 0x00;
		dv_phut = mm & 0x0f;
		chuc_giay = ss>>4 | 0x00;
		dv_giay = ss & 0x0f;
		uint8_t ht[8] = {number[chuc_gio],number[dv_gio],0b0010111,number[chuc_phut],number[dv_phut],0b1100111,number[chuc_giay],number[dv_giay]};
		for(int i=0; i<8;i++)
		{
			sendData(i+1, ht[7-i]);
		}
	}
    return 0;
}

