#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <wiringPi.h>
#include <wiringPiSPI.h>


#define spi0    0
#define SCAN    0x0B
#define DISPLAY 0x0F
#define DISPLAY_NORMAL_OPERATION 0x00
#define SHUTDOWN 0x0C
#define SHUTDOWN_NORMAL_OPERATION 0x01
uint32_t id = 20146133;
uint8_t i = 0;
const char led7Seg[11] = {0x7E,0x30,0x6D,0x79,0x33,0x5B,0x5F,0x70,0x7F,0x7B,0x00};
const char indexLed[8] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
const char digitNumber[8] = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07};
unsigned char data[2];

int main(void){
     
    wiringPiSPISetup(spi0,10000000);
    data[0] = DISPLAY;
    data[1] = DISPLAY_NORMAL_OPERATION;
    wiringPiSPIDataRW(spi0,data, 2);
    data[0] = SHUTDOWN;
    data[1] = SHUTDOWN_NORMAL_OPERATION;
    wiringPiSPIDataRW(spi0,data, 2);
    delay(1);
    data[0] = SCAN;
    data[1] = digitNumber[7];
    wiringPiSPIDataRW(spi0,data, 2);
    delay(1);

    data[0] = 0x01;
    data[1] = 0b00001111;
    wiringPiSPIDataRW(spi0,data, 2);

   while(1)
    {
        /*while(id>0)
        {    
            data[0] = indexLed[i];
            data[1] = led7Seg[id%10];
            wiringPiSPIDataRW(spi0,data, 2);
            id = id/10;
            i++;
            delay(1); 
        }  */
    }
   
    return 0;
}