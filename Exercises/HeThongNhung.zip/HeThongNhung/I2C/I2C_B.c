#include <wiringPi.h>
#include <wiringPiSPI.h>
#include <wiringPiI2C.h>

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>


int mpu;
float temp;
#define INT_pin  7
#define spi_speed 1000000
void initMpu(void)
{
	wiringPiI2CWriteReg8(mpu, 0x19, 9);		//sample rate
	wiringPiI2CWriteReg8(mpu, 0x1A, 0x02);	//DLPF
	wiringPiI2CWriteReg8(mpu, 0x1B, 0x08);	//Gyro
	wiringPiI2CWriteReg8(mpu, 0x1C, 0x10);	//ACC
	wiringPiI2CWriteReg8(mpu, 0x38, 1);		//Interrupt
	wiringPiI2CWriteReg8(mpu, 0x6B, 1);		//CLK source
}

void dataReady(void)
{
	// clear interrupt flag
	wiringPiI2CReadReg8(mpu, 0x3A);
	// read sensor data
	
}

int16_t read_raw_data()
{
	int16_t high_byte,low_byte,value;
	high_byte = wiringPiI2CReadReg8(mpu, 0x41);
	low_byte  =  wiringPiI2CReadReg8(mpu, 0x42);
	value = (high_byte << 8) | low_byte;
	return value;
}


//setup max7219
#define spi0   0
unsigned char data[2];
float Temp;

int pow_int(uint8_t a,uint8_t b)
{
    int result = 1;
    for(int i = b;i>0;i--)
    {
        result = result*a;
    }
    return result;
}

void senddata(unsigned char address,unsigned char value)
{
    data[0] = address;
    data[1] = value;
    wiringPiSPIDataRW(spi0,data,2);
}

void initMax7219(void)
{
    // set decode mode : 0x09FF: Thanh ghi su dung BCD
    senddata(0x09,0xFF);
    // set intensity : 0x0A09:   Do Sang
    senddata(0x0A,0x09);
    // set scanlimit
    senddata(0x0B,0);   
    // no shutdown, turn off display test
    senddata(0x0C,1);
    senddata(0x0F,0);
}

void display_number(uint32_t num)
{
    //count the number
    uint8_t count = 1;
    uint32_t n = num;  ///12345
    while(n/10)        //khi chia lon hon 0 thi dung 
    {
        count++;      //1234-123-12-1
        n = n/10;
        //printf("%d",n);
    }
    //set scanlimit
    senddata(0x0B,count-1);
    //display number
    for(int i = 0;i<count;i++)
    {
        senddata(i+1,num%10);
        num = num/10;
    }
}

void display_float_number(float num,uint8_t decimal) //5347.6734
{
    uint8_t count_2 = 1;
    int32_t integer = 0;
    int32_t dot = 0;
    int32_t dec = 0;
    int32_t number = 0;

    integer = (long)num;                   //5347
    dot = integer%10;
    dec = (long)(num*pow_int(10,decimal))%(long)(pow_int(10,decimal)); //67

    number = (integer*pow_int(10,decimal) + dec); //534767
    display_number(number);

    while(dec/10)        
    {
        count_2++;      
        dec = dec/10;
    }

    senddata(1+count_2,dot|0x80);

}


int main(void)
{
    wiringPiSetup();
    // setup SPI interface
    wiringPiSPISetup(spi0,spi_speed);

    //setup I2C
    mpu = wiringPiI2CSetup(0x68);

    //check connection on reset value

    if(wiringPiI2CReadReg8(mpu, 0x75)!= 0x68)
    {
		printf("Connection fail. \n");
		exit(1);
	}

	// setup operational mode for mpu6050
	initMpu();

	// setup interrupt for INT pin
	pinMode(INT_pin, INPUT);
	wiringPiISR(INT_pin, INT_EDGE_RISING, &dataReady);
    
    while(1)
    {   
        temp = read_raw_data();
        printf(" %d\n",temp);
        float Temp = temp/340.0 + 36.53;
        printf("%0.2f\n",Temp);
        
        display_float_number(Temp,4);
        delay(500);
    }

    return 0;
}