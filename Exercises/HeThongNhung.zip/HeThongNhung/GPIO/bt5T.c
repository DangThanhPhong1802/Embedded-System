#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <unistd.h>
#include <stdlib.h>

#define red 2
#define blue 3
#define green 0
#define bt0 22
#define bt1 23
#define bt2 24

u_int8_t led[3] ={2,0,3};
u_int8_t r[3] ={1,0,0};
u_int8_t g[3] ={0,1,0};
u_int8_t b[3] ={0,0,1};
u_int16_t currentCountValue = 0;
u_int16_t TB = 0;
u_int8_t valueRandom;
volatile u_int16_t count;
volatile u_int16_t currentCountValueButton;
const u_int16_t setTime = 1000;
const u_int16_t setTimeWin = 1000;
// Hien thi led
void status(void)
{
    digitalWrite(led[0], r[valueRandom]);
    digitalWrite(led[1], g[valueRandom]);
    digitalWrite(led[2], b[valueRandom]);
}
void ledOff(void)
{
    digitalWrite(led[0], 0);
    digitalWrite(led[1], 0);
    digitalWrite(led[2], 0);
    delay(2000);
}
// Time
int time()
{
    count ++;
    delay(1);   
    return count;
}
// Interrupt button
void btn0(void)
{
    if(currentCountValue <setTimeWin)
    {
        currentCountValueButton = currentCountValue;    
    }
    else
    {
        currentCountValueButton = setTimeWin + 1;
    }
    currentCountValue = setTime + 1;
    ledOff();
}

int main(void)
{
 
 wiringPiSetup();
 // Setup pin
 pinMode(red, OUTPUT);
 pinMode(blue, OUTPUT);
 pinMode(green, OUTPUT);
 pinMode(bt0, INPUT);
 pinMode(bt1, INPUT);
 pinMode(bt2, INPUT);
 // Setup Interrupt button
 wiringPiISR(bt0, INT_EDGE_RISING, &btn0);
// Begin all led off
digitalWrite(red, LOW);
digitalWrite(green, LOW);
digitalWrite(blue,LOW);


 while(1)
 {
    for(int i=0;i<10;i++){
    valueRandom = rand() %3+0;
    switch (valueRandom)
    {
        case 0:
            status();
            currentCountValue = 0;
            currentCountValueButton = 0;
            count = 0;
            break;
        case 1:
            status();
            currentCountValue = 0;
            currentCountValueButton = 0;
            count = 0;
            break;
        case 2:
            status();
            currentCountValue = 0;
            currentCountValueButton = 0;
            count = 0;       
            break;
    }
    while(currentCountValue < setTime)
    {
        currentCountValue = time(); 
    }
    if((currentCountValueButton > 0)&&(currentCountValueButton < setTimeWin))
    {
        printf("Thang cuoc: ");
        printf("%ld ms\n", currentCountValueButton);
        ledOff();
    }
    else 
    {
        printf("...\n");
        currentCountValueButton = 1000;
        ledOff(); 
    }
    if(i>0){
    TB = (TB + currentCountValueButton)/2;
    }
    else
    TB = currentCountValueButton;
    }
    printf("Tgian nhan trb: %ld ms\n",TB);
 }

return 0;
}
