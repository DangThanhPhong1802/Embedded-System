#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include <stdint.h>
#include <softPwm.h>

#define RED 2
#define BLUE 3
#define GREEN 0
#define BT1 22
#define BT2 23
#define BT3 24

uint8_t duty=0;
uint8_t LED[3]={2,0,3};
uint8_t valueRandom;

void BTN1(void){
    
    if(valueRandom==0){
        digitalWrite(RED, HIGH);
        digitalWrite(GREEN, LOW);
        digitalWrite(BLUE, LOW);
    }
    if(valueRandom==1){
        digitalWrite(RED, LOW);
        digitalWrite(GREEN, HIGH);
        digitalWrite(BLUE, LOW);
    }
    if(valueRandom==2){
        digitalWrite(RED, LOW);
        digitalWrite(GREEN, LOW);
        digitalWrite(BLUE, HIGH);
    }
}

void BTN2(void){
    if(valueRandom==0){
        for (int i=0; i<25; i++)
        softPwmWrite(RED, i*5);
    }
    if(valueRandom==1){
        for (int i=0; i<25; i++)
        softPwmWrite(GREEN, i*5);
    }
    if(valueRandom==2){
        for (int i=0; i<25; i++)
        softPwmWrite(BLUE, i*5);
    }
}

void BTN3(void){
    
}

int main(void){
    wiringPiSetup();

    //Start => All LED Off
    digitalWrite(RED, LOW);
    digitalWrite(GREEN, LOW);
    digitalWrite(BLUE, LOW);

    //Set Pin Button
    pinMode(BT1,INPUT);
    pinMode(BT2,INPUT);
    pinMode(BT3,INPUT);

    //Set Pin LED
    pinMode(RED, OUTPUT);
    pinMode(GREEN, OUTPUT);
    pinMode(BLUE, OUTPUT);


    //Set Interrupt
    wiringPiISR(BT1, INT_EDGE_RISING, &BTN1);
    wiringPiISR(BT2, INT_EDGE_RISING, &BTN2);
    wiringPiISR(BT3, INT_EDGE_RISING, &BTN3);

    
    
    while(1){
        valueRandom = rand() %3+0;
    }
    return 0;
}