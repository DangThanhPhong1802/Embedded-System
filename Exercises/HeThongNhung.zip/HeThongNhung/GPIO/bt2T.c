#include <stdio.h>
#include <wiringPi.h>
#include <stdint.h>
#include <softPwm.h>
//green 0
//red 2
//blue 3
#define LED 2
#define BT1 22
#define BT2 23
#define BT3 24
#define BT4 25
uint8_t duty=0;
void ngatBT1(void){
    duty = 25;
    softPwmWrite(LED,duty);
}
void ngatBT2(void){
    duty = 50;
    softPwmWrite(LED,duty);
}
void ngatBT3(void){
    duty = 75;
    softPwmWrite(LED,duty);
}
void ngatBT4(void){
    duty = 100;
    softPwmWrite(LED,duty);
}
int main(void){
    wiringPiSetup();
    pinMode(BT1,INPUT);
    pinMode(BT2,INPUT);
    pinMode(BT3,INPUT);
    pinMode(BT4,INPUT);
    pinMode(LED,OUTPUT);
    softPwmCreate(LED, duty, 100);
    wiringPiISR(BT1, INT_EDGE_RISING, &ngatBT1);
    wiringPiISR(BT2, INT_EDGE_RISING, &ngatBT2);
    wiringPiISR(BT3, INT_EDGE_RISING, &ngatBT3);
    wiringPiISR(BT4, INT_EDGE_RISING, &ngatBT4);
    printf("Trungasowiw\n");
    while(1);
    return 0;
}