#include<stdio.h>
#include<wiringPi.h>
#include<softPwm.h>
#include<stdint.h>
#include<unistd.h>
uint8_t led[3]={0,2,3};
#define btn1 22
#define btn2 23
// 0 : led red
// 2: led green
// 3 : led blue
void button1_interrupt(void){

    for(int i =0;i<3;i++)
    {
        // increase brightness
    for(int j = 0;j<21;j++){
        softPwmWrite(led[i],j*5);
        delay(200);
    }
        // reduce brightness
    for(int j =19;j>=0;j--){
        softPwmWrite(led[i],j*5);
        delay(200);
    }
    }
    
}
void button2_interrupt(void){

}


int main(){
    // cau hinh wiringPi
    wiringPiSetup();
    // set up GPIO for led and button
    for(int i= 0; i<3;i++){
        pinMode(led[i],OUTPUT);
        softPwmCreate(led[i],100,100);
    }
    pinMode(btn1,INPUT);
    pinMode(btn2,INPUT);

    // interrupt function
    wiringPiISR(btn1,INT_EDGE_BOTH,&button1_interrupt);
    wiringPiISR(btn2,INT_EDGE_BOTH,&button2_interrupt);

    while(1);

    return 0 ;
}