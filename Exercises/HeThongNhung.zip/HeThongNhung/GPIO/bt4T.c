#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <unistd.h>
#include <stdlib.h>

#define red 2
#define blue 3
#define green 0
#define bt0 22
#define bt1 23
#define bt2 24


u_int8_t led[3] ={2,0,3};
u_int8_t r[3] ={1,0,0};
u_int8_t g[3] ={0,1,0};
u_int8_t b[3] ={0,0,1};
u_int16_t currentCountValue = 0;
u_int8_t valueRandom;
volatile u_int16_t count;
volatile u_int16_t currentCountValueButton;
const u_int16_t setTime = 3000;
const u_int16_t setTimeWin = 1000;
// Hien thi led
void status(void)
{
    digitalWrite(led[0], r[valueRandom]);
    digitalWrite(led[1], g[valueRandom]);
    digitalWrite(led[2], b[valueRandom]);
}
// Color White
void white(void)
{
    for(int i = 0; i<3; i++){
        digitalWrite(led[0], 0);
        digitalWrite(led[1], 0);
        digitalWrite(led[2], 0);
        delay(1000);
        digitalWrite(led[0], 1);
        digitalWrite(led[1], 1);
        digitalWrite(led[2], 1);
        delay(1000);
    }
}
void ledOff(void)
{
    digitalWrite(led[0], 0);
    digitalWrite(led[1], 0);
    digitalWrite(led[2], 0);
    delay(3000);
}
// Time
int time()
{
    count ++;
    delay(1);   
    return count;
}
// Interrupt button
void btn0(void)
{
    if(valueRandom == 0)
    {
        if(currentCountValue <setTimeWin)
        {
            currentCountValueButton = currentCountValue;    
        }
        else
        {
            currentCountValueButton = setTimeWin + 1;
        }
    }
    currentCountValue = setTime + 1;
}

void btn1(void)
{
    if(valueRandom == 1)
    {
        if(currentCountValue <setTimeWin)
        {
            currentCountValueButton = currentCountValue;    
        }
        else
        {
            currentCountValueButton = setTimeWin + 1;
        }
    }
    currentCountValue = setTime;
}

void btn2(void)
{   
    if(valueRandom == 2)
    {
        if(currentCountValue <setTimeWin)
        {
            currentCountValueButton = currentCountValue;    
        }
        else
        {
            currentCountValueButton = setTimeWin + 1; // cong 1 de thoat currentCountValueButton !=0 trong switch case
        }
    }
    currentCountValue = setTime + 1; // cong 1 de thoat vong lap while trong main
}
int main(void)
{
 
 wiringPiSetup();
 // Setup pin
 pinMode(red, OUTPUT);
 pinMode(blue, OUTPUT);
 pinMode(green, OUTPUT);
 pinMode(bt0, INPUT);
 pinMode(bt1, INPUT);
 pinMode(bt2, INPUT);
 // Setup Interrupt button
 wiringPiISR(bt0, INT_EDGE_RISING, &btn0);
 wiringPiISR(bt1, INT_EDGE_RISING, &btn1);
 wiringPiISR(bt2, INT_EDGE_RISING, &btn2);
// Begin all led off
digitalWrite(red, LOW);
digitalWrite(green, LOW);
digitalWrite(blue,LOW);


 while(1)
 {
    valueRandom = rand() %3+0;
    switch (valueRandom)
    {
        case 0:
            status();
            currentCountValue = 0;
            currentCountValueButton = 0;
            count = 0;
            break;
        case 1:
            status();
            currentCountValue = 0;
            currentCountValueButton = 0;
            count = 0;
            break;
        case 2:
            status();
            currentCountValue = 0;
            currentCountValueButton = 0;
            count = 0;       
            break;
    }
    while(currentCountValue < setTime)
    {
        currentCountValue = time(); 
    }
    if((currentCountValueButton > 0)&&(currentCountValueButton < setTimeWin))
    {
        printf("%d\n", valueRandom);
        printf("Thang cuoc: ");
        printf("%ld ms\n", currentCountValueButton);
        white();
    }
    else 
    {
        printf("%d\n", valueRandom);
        printf("Thua cuoc\n");
        ledOff(); 
    }
     
 }

 return 0;
 }





