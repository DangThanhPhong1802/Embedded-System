#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>

#define red 2 //pin 11
#define green 0 // pin12
#define blue 3 // pin13
#define bt1 22 // pin29
#define bt2 23 // pin31
#define bt3 24 // pin33

uint8_t  led[3] = {2,0,3};
uint8_t  btn[3] = {22,23,24};
uint8_t r[10] ={ 100, 0   , 0  , 100 , 100,0   , 0  , 100, 50, 100};
uint8_t g[10] ={ 0  , 100 , 0  , 100 , 50 ,100 , 50 , 0  , 0,  100};
uint8_t b[10] ={ 0  , 0   , 100, 0   , 0  ,100 , 100, 100, 100,100}; 
float  duty = 0.1;
uint8_t color =0;


void interrupt_bt1(void)
{ 
    color +=1;
    if(color>5)     color = 0;
    softPwmWrite(led[0], r[color]*duty);
    softPwmWrite(led[1], g[color]*duty);
    softPwmWrite(led[2], b[color]*duty);
}
void interrupt_bt2(void)
{
 duty +=  0.1;
 if(duty>1) duty = 1;
 softPwmWrite(led[0], r[color]*duty);
 softPwmWrite(led[1], g[color]*duty);
 softPwmWrite(led[2], b[color]*duty);
}
void interrupt_bt3(void)
{
 duty -= 0.1;
 if(duty<0) duty = 0;
 softPwmWrite(led[0], r[color]*duty);
 softPwmWrite(led[1], g[color]*duty);
 softPwmWrite(led[2], b[color]*duty);
}
int main(void)
{
    wiringPiSetup();

    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }
    for(int i=0; i<3; i++){
        pinMode(btn[i],1);
    }
    wiringPiISR(bt1, INT_EDGE_RISING, &interrupt_bt1);
    wiringPiISR(bt2, INT_EDGE_RISING, &interrupt_bt2);
    wiringPiISR(bt3, INT_EDGE_RISING, &interrupt_bt3);
    
    while(1);

    return 0;
}