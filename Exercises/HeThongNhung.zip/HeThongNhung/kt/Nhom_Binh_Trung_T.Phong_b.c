/*Bài kiểm tra 1 
  Tên thành viên
  Đinh Văn Trung - 20146197
  Nguyễn Anh Bình - 20146097
  Đặng Thanh Phong - 20146132*/ 

#include <wiringPiI2C.h>
#include <wiringPi.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <wiringPiSPI.h>
#define spi0 0

int mpu;
int tp1,tp2;
int pn1,pn2;
int bien_huong ; 
int trangthai_copxe_st ;
float accel_x, accel_y,accel_z;
#define INT_pin  7
#define sampleRate 25
#define config 26
#define gyroConfig 27
#define accConfig 28
#define interrupt 56
#define PWRManagment 107
#define Acc_X	59
#define Acc_Y	61
#define Acc_Z	63
int huong[2] = {0x67,0x7E};
int open[3] = {0x7E, 0x67 , 0x15};
int cls[3] = {0x4E,0x0E,0x5B};
unsigned int number_7seg[10] = {0x7e, 0x30, 0x6d, 0x79, 0x33, 0x5b, 0x5f, 0x70, 0x7f, 0x7b};
unsigned int number[10] = {0b1111110, 0b0110000,0b1101101,0b1111001,0b0110011,0b1011011,0b1011111,0b1110000,0b1111111,0b1111011};
unsigned char font[][2] = {
  {'A',0b1110111},{'B',0b1111111},{'C',0b1001110},{'D',0b1111110},{'E',0b1001111},{'F',0b1000111},       
  {'G',0b1011110},{'H',0b0110111},{'I',0b0110000},{'J',0b0111100},{'L',0b0001110},{'N',0b1110110},       
  {'O',0b1111110},{'P',0b1100111},{'R',0b0000101},{'S',0b1011011},{'T',0b0001111},{'U',0b0111110},       
  {'Y',0b0100111},{'[',0b1001110},{']',0b1111000},{'_',0b0001000},{'a',0b1110111},{'b',0b0011111},       
  {'c',0b0001101},{'d',0b0111101},{'e',0b1001111},{'f',0b1000111},{'g',0b1011110},{'h',0b0010111},       
  {'i',0b0010000},{'j',0b0111100},{'l',0b0001110},{'n',0b0010101},{'o',0b1100011},{'p',0b1100111},       
  {'r',0b0000101},{'s',0b1011011},{'t',0b0001111},{'u',0b0011100},{'y',0b0100111},{'-',0b0000001},
  {' ',0b0000000},{'0',0b1111110},{'1',0b0110000},{'2',0b1101101},{'3',0b1111001},{'4',0b0110011},
  {'5',0b1011011},{'6',0b1011111},{'7',0b1110000},{'8',0b1111111},{'9',0b1111011},{'V',0b0111110},
  {'.',0b10000000},{'?',0b1100101},{'\0',0b0000000},};
//ham de doi chu sang nhi phan
unsigned int font_display(char text){
	for(int i = 0; font[i][0] != '\0'; i++)
	{
		if(font[i][0] == text)
		{
			return font[i][1];
		}
	}
}	
void sendData(unsigned char address, unsigned char value)
{
	unsigned char data[2] ;//16bit
	data[0] = address; //Dia chi hexa de chon mode can thay doi(datasheet)
	data[1] = value;   //Chon cac tuy chon thay doi(datasheet)
	wiringPiSPIDataRW(0, data, 2); //Gui data gom 2 byte qua channel 0
}
void initMax7219(void){
    // set decode mode 0x09FF
    sendData(0x09,0x00);
    // set intensity : 0x0A09 
    sendData(0x0A,9);
    // set scanlimit 
    sendData(0x0B,7);
    // no shutdown , turn off display test 
    sendData(0x0C,1);
    sendData(0x0F,0);
}
void clr(void){
    for(int i=1;i<9;i++)
    {
        sendData(i,0x00);
    }
}
void initMpu(void){
	wiringPiI2CWriteReg8(mpu, sampleRate, 15);			//sample rate
	wiringPiI2CWriteReg8(mpu, config, 0x03);				//DLPF
	wiringPiI2CWriteReg8(mpu, gyroConfig, 0x08);		//Gyro
	wiringPiI2CWriteReg8(mpu, accConfig, 0x00);			//ACC
	wiringPiI2CWriteReg8(mpu, interrupt, 1);			//Interrupt
	wiringPiI2CWriteReg8(mpu, PWRManagment, 0x01);		//CLK source
}

void dataReady(void){
	// clear interrupt flag
	wiringPiI2CReadReg8(mpu, 0x3A);
	// read sensor data
}

int16_t readSensor(unsigned char sensor){
	int16_t high, low, data;
	high = wiringPiI2CReadReg8(mpu, sensor);
	low = wiringPiI2CReadReg8(mpu, sensor +1);
	data = (high << 8) | low;
	return data;
}
void display_float(float num, uint8_t dec){
    int32_t integerPart = num;
    int32_t fractionalPart = (num - integerPart) * pow(10,dec);
    int32_t number = integerPart*pow(10,dec) + fractionalPart;
    // count the number of digits
    uint8_t count=1;
    int32_t n = number;
    while(n/10){
        count++;
        n = n/10;
    }
    // set scanlimit
    sendData(0x0B,count + 4);
    // dislay number
    for(int i=0; i<count;i++){
        if(i==dec)
            sendData(i+2,number_7seg[number%10]|0x80); // turn on dot segment 
        else
            sendData(i+2,number_7seg[number%10]);
        number = number/10;
    }
}
int main(void){
    // Setup WiringPi
    wiringPiSetup();
	wiringPiSPISetup(spi0,20000000);
    initMax7219();
    clr();
	// setup i2c interface
	mpu = wiringPiI2CSetup(0x68);
	// check connection
	if(wiringPiI2CReadReg8(mpu, 0x75)!= 0x68){
		printf("Connection fail. \n");
		exit(1);
	}
	// setup operational mode for mpu6050
	initMpu();
	// setup interrupt for INT pin
	pinMode(INT_pin, INPUT);
	wiringPiISR(INT_pin, INT_EDGE_RISING, &dataReady);
    accel_x =   (float)readSensor(0x3B)/8192;
    accel_y =   (float)readSensor(0x3D)/8192;
    accel_z =   (float)readSensor(0x3F)/8192;
    while(1){
        float Ax = (float)readSensor(Acc_X)/4096.0;
		float Ay = (float)readSensor(Acc_Y)/4096.0;
		float Az = (float)readSensor(Acc_Z)/4096.0;
		float pitch = atan2(Ax, sqrt(pow(Ay,2)+pow(Az,2)))*180/M_PI;
		float roll = atan2(Ay, sqrt(pow(Ax,2)+pow(Az,2)))*180/M_PI;
		
        //printf("Goc: %f\n", pitch);
		float w =  abs(pitch-pitch2)*0.1;
		//printf("Vantocgoc: %.2f\n",w);
		pitch2 = pitch;
		if(pitch >= 0) pitch = pitch;
		else if(pitch <=0) pitch = -pitch;
        display_float(pitch,1);
		delay(100);
		if ((-10.0<pitch)&(pitch<10)){
			sendData(5, font_display('C'));
			sendData(4, font_display('L'));
    		sendData(3, font_display('O'));
			sendData(2, font_display('S'));
    		sendData(1, font_display('E'));
		}
		else{
			sendData(5, font_display(' '));
			sendData(4, font_display('O'));
    		sendData(3, font_display('P'));
			sendData(2, font_display('E'));
    		sendData(1, font_display('N'));
		}
	}
    return 0;
}