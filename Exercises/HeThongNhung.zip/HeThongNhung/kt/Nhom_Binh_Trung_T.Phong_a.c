/*Bài kiểm tra 1 
  Tên thành viên
  Đinh Văn Trung - 20146197
  Nguyễn Anh Bình - 20146097
  Đặng Thanh Phong - 20146132*/ 

#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <wiringPiSPI.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>	
#include <wiringPiI2C.h>
#include <stdint.h>

#define R 2//
#define G 0//
#define B 3//
#define BT1 22//
#define BT2 23//
#define BT3 24//
#define BT4 6//
#define INT_pin 7//7

#define MPU_ADDRESS 0x68
#define WHO_AM_I 0x75
#define TEMP_OUT 0x41
#define DLPF_CFG 0x1A
#define SR 0X19
#define GYRO_CONFIG 0x1B
#define ACCEL_CONFIG 0x1C
#define INT_ENABLE 0x38
#define PWR_MGMT_1 0x6B

#define ACCEL_XOUT 0x3B
#define ACCEL_YOUT 0x3D
#define ACCEL_ZOUT 0x3F

#define channel_spi 0
#define speed_spi 1000000
//Enable True/False
typedef enum { false, true } bool;

int mpu;
float Ax2;

unsigned int number_7seg[10] = {0x7e, 0x30, 0x6d, 0x79, 0x33, 0x5b, 0x5f, 0x70, 0x7f, 0x7b};
 /*kiem tra lai bang ma coi co sai hay khong */

unsigned char font[][2] = {
  {'A',0b1110111},{'B',0b1111111},{'C',0b1001110},{'D',0b1111110},{'E',0b1001111},{'F',0b1000111},       
  {'G',0b1011110},{'H',0b0110111},{'I',0b0110000},{'J',0b0111100},{'L',0b0001110},{'N',0b1110110},       
  {'O',0b1111110},{'P',0b1100111},{'R',0b0000101},{'S',0b1011011},{'T',0b0001111},{'U',0b0111110},       
  {'Y',0b0100111},{'[',0b1001110},{']',0b1111000},{'_',0b0001000},{'a',0b1110111},{'b',0b0011111},       
  {'c',0b0001101},{'d',0b0111101},{'e',0b1001111},{'f',0b1000111},{'g',0b1011110},{'h',0b0010111},       
  {'i',0b0010000},{'j',0b0111100},{'l',0b0001110},{'n',0b0010101},{'o',0b1100011},{'p',0b1100111},       
  {'r',0b0000101},{'s',0b1011011},{'t',0b0001111},{'u',0b0011100},{'y',0b0100111},{'-',0b0000001},
  {' ',0b0000000},{'0',0b1111110},{'1',0b0110000},{'2',0b1101101},{'3',0b1111001},{'4',0b0110011},
  {'5',0b1011011},{'6',0b1011111},{'7',0b1110000},{'8',0b1111111},{'9',0b1111011},{'V',0b0111110},
  {'.',0b10000000},{'?',0b1100101},{'\0',0b0000000}};
  //Cac ham lien quan SPI

	//Truyen data
	void sendData(unsigned char address, unsigned char value)
	{
		unsigned char data[2] ;//16bit
		data[0] = address; //Dia chi hexa de chon mode can thay doi(datasheet)
		data[1] = value;   //Chon cac tuy chon thay doi(datasheet)
		wiringPiSPIDataRW(0, data, 2); //Gui data gom 2 byte qua channel 0	
	} 
	
	unsigned int font_display(char text)
	{
		for(int i = 0; font[i][0] != '\0'; i++)
		{
			if(font[i][0] == text) return font[i][1];
		}
	}
	
	//Khoi tao man LCD
	void Init_7219(void)
	{
		//set decode mode
		sendData(0x09, 0xff);
		//set intensity
		sendData(0x0A, 0x01);
		//set scan limit
		sendData(0x0B, 0x07);
		//set shutdown
		sendData(0x0C, 0x01);
		//set display test
		sendData(0x0F, 0x00);
	}
// true : la xai theo he thong
// false : la xai theo y minh
	void decode_mode(bool select)
	{
		if (select == true) sendData(0x09, 0xff); // mode : theo he thong
		else sendData(0x09, 0x00); // mode : theo y cua minh
	}

	//Clear display
	void clear_data()
	{
		decode_mode(true);
		for (int i = 1; i < 9; i ++)
		{
			sendData(i, 0);	
		}
		decode_mode(false);
	}

	//Hien thi so thuc (.2f)
	void display_real_number(float sothuc)
	{
		float sothucx100;
		int16_t dvi = 0, chuc = 0, tram = 0, ngan = 0;
		sothucx100 = sothuc*100;
			
		printf("\r%f", sothuc);
		fflush(stdout);
			
		ngan = sothucx100 / 1000;
		tram = (sothucx100 - ngan*1000) / 100;
		chuc = (sothucx100 - ngan*1000 - tram*100) / 10;
		dvi =  (int)sothucx100%10;
			
		sendData(0x09, 0x00);
		sendData(3, number_7seg[dvi]);
		sendData(4, number_7seg[chuc]|0x80);
		sendData(5, number_7seg[tram]);
		//sendData(4, number_7seg[ngan]);		
	}	
	
	//Hien thi so nguyen 2 chu so bat ki len man hinh
	void display_uint_number(unsigned int pos, unsigned int songuyen)
	{
		unsigned int dvi = 0, chuc = 0, tram = 0, ngan = 0;
			
		ngan = songuyen / 1000;
		tram = (songuyen - ngan*1000) / 100;
		chuc = (songuyen - ngan*1000 - tram*100) / 10;
		dvi =  songuyen%10;
			
		sendData(0x09, 0x00);
		sendData(pos, number_7seg[dvi]);
		sendData(pos + 1, number_7seg[chuc]);
	}
	
	//Set up pro (so chu so, do sang, ...)
	void setting_7219(unsigned int numDisplay, unsigned int Intensity)
	{
		sendData(0x0A, Intensity);
		sendData(0x0B, numDisplay - 1);
	}
	
	//shutdown
	void display_ON(bool select)
	{
		if (select == 1) sendData(0x0C, 0x01);
		else sendData(0x0C, 0x00);
	}
	
	void test_display(bool select)
	{
		if (select == 1) sendData(0x0F, 0x01);
		else sendData(0x0F, 0x00);
	}
	/* hien thi ki tu do minh set up */
	void Display_char_no_decode(unsigned char position, char text)
	{
		unsigned char text_bina;
		for(int i = 0; font[i][0] != '\0'; i++){
			if(font[i][0] == text){
				text_bina = font[i][1];
				sendData(position, text_bina);
			}
		}
	}

	//Move in screen
	void move_left(unsigned char string[100], bool is_left, unsigned int solanchay,
					unsigned int time_milisec)
	{
		decode_mode(false);
		unsigned int length;
		unsigned int m[20] = {20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1};
		length = strlen(string);

		if (is_left == false)
		{
			for (int i = 0; i < solanchay*length; i ++)
			{	
				for (int x = 0; x < length; x++)
				{
					if ((m[x] < 9)&(m[x] > 0))
					sendData(m[x], font_display(string[x]));
				}
			
				for (int j = 0; j < length; j++)
				{
					m[j] = m[j] - 1;
					if (m[j] < 1) m[j] = length;
				}
				delay(time_milisec);
			}
		}
	}


    //Cac ham lien quan I2C
	//Khoi tao MPU6050
	void initMPU()
	{
		wiringPiI2CWriteReg8(mpu, SR, 9);
		wiringPiI2CWriteReg8(mpu, DLPF_CFG, 0x03);
		wiringPiI2CWriteReg8(mpu, GYRO_CONFIG, 0x08);
		wiringPiI2CWriteReg8(mpu, ACCEL_CONFIG, 0x00);
		wiringPiI2CWriteReg8(mpu, INT_ENABLE, 1);
		wiringPiI2CWriteReg8(mpu, PWR_MGMT_1, 1);
	}

	int16_t readSensor(uint8_t address)
	{
		int16_t value;
		value = wiringPiI2CReadReg8(mpu, address) << 8 | wiringPiI2CReadReg8(mpu, address+1);
		return value;
	}
typedef struct{
	int x;
	int y;
} Plane;
Plane plane;
int main(){
    // set up rasp
    wiringPiSetup();
    // set up SPI 
    wiringPiSPISetup(channel_spi,speed_spi);
    // set up thu vien max7219 
    Init_7219();
	//Set up I2C interrupt
	mpu = wiringPiI2CSetup(MPU_ADDRESS);
	//Test I2C connection
	if (wiringPiI2CReadReg8(mpu, WHO_AM_I) != MPU_ADDRESS)
	{
		printf("Connection fail.\n");
		exit(1);
	}
	//set up operation mode for mpu-6050
	initMPU();
    clear_data();
    //
    float Ax = 0;
    float Ay = 0; 
    float Az = 0;
    float Angle1 = 0;
    float Angle2 = 0;
	int Angle1_old = 0 ;
	int Angle2_old = 0 ;
    float check_Angle=0;
    //Initilize plane
	plane.x = 4;
	plane.y = 4;
    float v =0;
    while(1){
        float Ax = (float)readSensor(ACCEL_XOUT)/8192.0;
		float Ay = (float)readSensor(ACCEL_YOUT)/8192.0;
		float Az = (float)readSensor(ACCEL_ZOUT)/8192.0;
		float Angle1 = atan2(Ax, sqrt(pow(Ay,2)+pow(Az,2)))*180/M_PI; // pitch
		float Angle2 = atan2(Ay, sqrt(pow(Ax,2)+pow(Az,2)))*180/M_PI; // roll
        check_Angle = Angle1;
        if(Angle1 >= 0) Angle1 = Angle1;
		else if(Angle1 <=0)Angle1 = -Angle1;

        if(Angle2 >= 0) Angle2 = Angle2;
		else if(Angle2 <=0) Angle2 = -Angle2;
        if (Angle2 > Angle2_old + 5)
		{
			printf("\nUp %.5f\n", Angle2);
            Display_char_no_decode(7,'P');
            Display_char_no_decode(8,'U');
			plane.x++;
		}
	
		if (Angle2 < Angle2_old - 5)
		{
			printf("\nDown %.5f\n", Angle2);
            Display_char_no_decode(8,'D');
            Display_char_no_decode(7,'N');
			plane.x--;
		}
		fflush(stdout);
        if (plane.x > 7) plane.x = 7; 
		if (plane.y > 7) plane.y = 7; 
		
		if (plane.x < 0) plane.x = 0; 
		if (plane.y < 0) plane.y = 0; 
        Angle1_old = Angle1;
		Angle2_old = Angle2;
        delay(500);
        // Hien thi ra man hinh  
        Display_char_no_decode(2,'-');
        Display_char_no_decode(6,'-');
        display_real_number(Angle1);
        /* tinh van toc cua xe */
        v= (v+(Ax)*0.5);
        if(v<0) v=-v;
        Ax2 = Ax;
        if(v<=0.5){
            Display_char_no_decode(1,'P');
        }
        if(v>0.5){
            Display_char_no_decode(1,'D');
        }
        printf("\nvan toc: %.2f",v);
        printf("\n%.2f",check_Angle);
        if((v>11.1)){
            for (int j = 12; j > 0; j--)
			{
				//Thay doi do sang
				setting_7219(8,j);
                display_real_number(Angle1);
				delay(50);
            }	
        }
    }
    return 0;
    }