#include "full_lib.h"

int main(){
    wiringPiSPISetup(0, 10000000); //channel 1, 10MHz
	Init_7219();
	sendData(0x0b, 0x05);
	decode_mode(true);
    while(1){
        display_real_number(cpu_temp());
        delay(1000);
    }
    return 0;
}