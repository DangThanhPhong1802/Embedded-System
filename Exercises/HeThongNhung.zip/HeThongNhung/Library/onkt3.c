#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <wiringPiSPI.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>	
#include <wiringPiI2C.h>
#include <stdint.h>

#define channel_spi 0
#define speed_spi 1000000

typedef enum{false,true} bool;
int mpu;
unsigned int number_7seg[10] = {0x7e, 0x30, 0x6d, 0x79, 0x33, 0x5b, 0x5f, 0x70, 0x7f, 0x7b};
unsigned char font[][2] = {
  {'A',0b1110111},{'B',0b1111111},{'C',0b1001110},{'D',0b1111110},{'E',0b1001111},{'F',0b1000111},       
  {'G',0b1011110},{'H',0b0110111},{'I',0b0110000},{'J',0b0111100},{'L',0b0001110},{'N',0b1110110},       
  {'O',0b1111110},{'P',0b1100111},{'R',0b0000101},{'S',0b1011011},{'T',0b0001111},{'U',0b0111110},       
  {'Y',0b0100111},{'[',0b1001110},{']',0b1111000},{'_',0b0001000},{'a',0b1110111},{'b',0b0011111},       
  {'c',0b0001101},{'d',0b0111101},{'e',0b1001111},{'f',0b1000111},{'g',0b1011110},{'h',0b0010111},       
  {'i',0b0010000},{'j',0b0111100},{'l',0b0001110},{'n',0b0010101},{'o',0b1100011},{'p',0b1100111},       
  {'r',0b0000101},{'s',0b1011011},{'t',0b0001111},{'u',0b0011100},{'y',0b0100111},{'-',0b0000001},
  {' ',0b0000000},{'0',0b1111110},{'1',0b0110000},{'2',0b1101101},{'3',0b1111001},{'4',0b0110011},
  {'5',0b1011011},{'6',0b1011111},{'7',0b1110000},{'8',0b1111111},{'9',0b1111011},{'V',0b0111110},
  {'.',0b10000000},{'?',0b1100101},{'\0',0b0000000}};
//Cac ham lien quan SPI

	//Truyen data
	void sendData(unsigned char address, unsigned char value)
	{
		unsigned char data[2] ;//16bit
		data[0] = address; //Dia chi hexa de chon mode can thay doi(datasheet)
		data[1] = value;   //Chon cac tuy chon thay doi(datasheet)
		wiringPiSPIDataRW(0, data, 2); //Gui data gom 2 byte qua channel 0	
	} 
	
	unsigned int font_display(char text)
	{
		for(int i = 0; font[i][0] != '\0'; i++)
		{
			if(font[i][0] == text) return font[i][1];
		}
	}
	
	//Khoi tao man LCD
	void Init_7219(void)
	{
		//set decode mode
		sendData(0x09, 0xff);
		//set intensity
		sendData(0x0A, 0x01);
		//set scan limit
		sendData(0x0B, 0x07);
		//set shutdown
		sendData(0x0C, 0x01);
		//set display test
		sendData(0x0F, 0x00);
	}
// true : la xai theo he thong
// false : la xai theo y minh
	void decode_mode(bool select)
	{
		if (select == true) sendData(0x09, 0xff); // mode : theo he thong
		else sendData(0x09, 0x00); // mode : theo y cua minh
	}

	//Clear display
	void clear_data()
	{
		decode_mode(true);
		for (int i = 1; i < 9; i ++)
		{
			sendData(i, 0);	
		}
		decode_mode(false);
	}
void display_uint_number(unsigned int pos, unsigned int songuyen)
	{
		unsigned int dvi = 0, chuc = 0, tram = 0, ngan = 0;
			
		ngan = songuyen / 1000;
		tram = (songuyen - ngan*1000) / 100;
		chuc = (songuyen - ngan*1000 - tram*100) / 10;
		dvi =  songuyen%10;
			
		sendData(0x09, 0x00);
		sendData(pos, number_7seg[dvi]);
		sendData(pos + 1, number_7seg[chuc]);
	}
// hien thi ki tu tai vi tri bat ki
void Display_char_no_decode(unsigned char position, char text)
	{
		unsigned char text_bina;
		for(int i = 0; font[i][0] != '\0'; i++){
			if(font[i][0] == text){
				text_bina = font[i][1];
				sendData(position, text_bina);
			}
		}
	}
//cpu temp
float cpu_temp()
{
	FILE *tempfile;
	float temp;
	tempfile  = fopen("/sys/class/thermal/thermal_zone0/temp", "r");
	fscanf(tempfile, "%f", &temp);
	temp = temp / 1000;
	fclose(tempfile);
	return temp;
} 
int main(){
	wiringPiSetup();

	/* set up SPI*/
	wiringPiSPISetup(channel_spi,speed_spi);
	/* set up max7219*/
	Init_7219();
	clear_data();
	
	printf("Setup Completed");
	fflush(stdout);
	//Khai bao bien
	time_t rawtime;
	struct tm *ct;
	unsigned int hh,mm,ss;
	while(1){
		// lay gia tri thoi gian thuc tu rasp
		time(&rawtime);
		ct = localtime(&rawtime);
		//Hien thi gio
		display_uint_number(4, ct->tm_min);
		display_uint_number(7, ct->tm_hour);
		// hien thi ki tu 
		Display_char_no_decode(3,'-');
		Display_char_no_decode(6,'h');
		// hien thi nhiet do cpu
		display_uint_number(1,(int)cpu_temp());
		//Cap nhat sau 2s
		delay(2000);
	}
	return 0;
}