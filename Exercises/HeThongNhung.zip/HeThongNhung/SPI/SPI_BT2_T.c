#include <wiringPiSPI.h>
#include <stdio.h>
#include <stdint.h>
#include <wiringPi.h>
#define spi0    0
uint8_t buf[2];
uint8_t led[8] = {0x7D, 0x1D, 0x1C, 0x10, 0x3D, 0x00, 0x30, 0x7B};
uint8_t digit[8] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
uint8_t scan[8] = {0x00,0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07};
uint32_t count=0;
void sendData(uint8_t address, uint8_t data){
    buf[0] = address;
    buf[1] = data;
    wiringPiSPIDataRW(spi0, buf, 2);
}
void Init(void){
    // no shutdown, no display test
    sendData(0x0C, 0x01);
    sendData(0x0F, 0x00);
    // scan limit 0x0B07
    sendData(0x0B, 7);
    // set intensity
    sendData(0x0A, 0x01);
    // set BCD
    sendData(0x09, 0x00);
}
void Lui(void){
    sendData(0x01,0x08);
    sendData(0x02,0x0C);
    sendData(0x03,0x0E);
    sendData(0x04,0xFF);
    sendData(0x05,0xFF);
    sendData(0x06,0x0E);
    sendData(0x07,0x0C);
    sendData(0x08,0x08);
}
void TienToi(void){
    sendData(0x01,0x08);
    sendData(0x02,0x0C);
    sendData(0x03,0x0E);
    sendData(0x04,0xFF);
    sendData(0x05,0xFF);
    sendData(0x06,0x0E);
    sendData(0x07,0x0C);
    sendData(0x08,0x08);
}
void TienTrai(void){
    sendData(0x01,0x0C);
    sendData(0x02,0x3C);
    sendData(0x03,0x7E);
    sendData(0x04,0xFF);
    sendData(0x05,0x0C);
    sendData(0x06,0x0C);
    sendData(0x07,0x0C);
    sendData(0x08,0x0C);
}
void TienPhai(void){
    sendData(0x01,0x0C);
    sendData(0x02,0x0C);
    sendData(0x03,0x0C);
    sendData(0x04,0x0C);
    sendData(0x05,0xFF);
    sendData(0x06,0x7E);
    sendData(0x07,0x3C);
    sendData(0x08,0x0C);
}
int main(void){
    wiringPiSPISetup(spi0, 1000000);
    wiringPiSetup();
    Init();
    for(int i = 1; i<9;i++){
        sendData(i,0);
    }
    TienToi();

    /*for(int a=0; a<10; a++){
        sendData(digit[3],a);
        for(int b=0; b<10; b++){
            sendData(digit[2],b);
            for(int i=0; i<10; i++){
                sendData(digit[1],i);
                for(int j=0; j<10; j++){
                    sendData(digit[0],j);
                    delay(10);
                    count++;
                    if(count>10)    sendData(0x0B, 1);
                    if(count>100)    sendData(0x0B, 2);
                    if(count>1000)    sendData(0x0B, 3);
                }
            }
        }
    }*/
    return 0;
}