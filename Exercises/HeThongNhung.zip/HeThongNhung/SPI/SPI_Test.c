#include <stdio.h>
#include<stdint.h>
#include<wiringPi.h>
#include<wiringPiSPI.h>
#include<stdlib.h>
#include<wiringPiI2C.h>
#include<math.h>


#define spi0 0
#define spi_speed 1000000
#define INT_pin  7
unsigned int mpu;
unsigned char data[2];
int16_t tempBin;
int16_t tempDec;
int16_t tempC;
float temp,temp1;
uint8_t digit[8] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};

void SendData(unsigned char address,unsigned char value){
    data[0]= address;
    data[1]=value;
    wiringPiSPIDataRW(spi0,data,2);
}
void initMpu(void){
    // sample rate =100Hz,enable DLPF
    wiringPiI2CWriteReg8(mpu,0x19,9);
    // DLPF fc =9Mhz
    wiringPiI2CWriteReg8(mpu,0x1A,0x02);
    // gyro +-500
    wiringPiI2CWriteReg8(mpu,0x1B,0x08);
    // acc Fs+-8g
    wiringPiI2CWriteReg8(mpu,0x1C,0x10);
    //Interrupt
    wiringPiI2CWriteReg8(mpu, 0x38, 1);		
    //CLK source
	wiringPiI2CWriteReg8(mpu, 0x6B, 1);		
}
void dataReady(void){
	// clear interrupt flag
	wiringPiI2CReadReg8(mpu, 0x3A);
	// read sensor data
}
void Init(void){
    // set decode mode : 0x09FF
    SendData(0x09,0xFF);
    // set intensity : 0x0A09
    SendData(0x0A,0x07);
    SendData(0x0B,7);
    // set scan_limit : 0x0B07
    SendData(0x0C,1);
    SendData(0x0F,0);
}
void display_float(float num, uint8_t dec){
    int32_t integerPart = num;
    int32_t fractionalPart = (num - integerPart) * pow(10,dec);
    int32_t number = integerPart*pow(10,dec) + fractionalPart;
    // count the number of digits
    uint8_t count=1;
    int32_t n = number;
    while(n/10){
        count++;
        n = n/10;
    }
    // set scanlimit
    SendData(0x0B, count-1);
    // dislay number
    for(int i=0; i<count;i++){
        if(i==dec)
            SendData(i+1,(number%10)|0x80); // turn on dot segment 
        else
            SendData(i+1,number%10);
        number = number/10;
    }
}
int convertB2D(int16_t value)
{
    for(int i=0; i<16; i++)
    {
        tempDec += (tempBin>>i && 0x0001)*pow(2,i);
    }
    return tempDec;
    
}
int main(){
    wiringPiSetup();
    wiringPiSPISetup(spi0,spi_speed);
    Init();
    mpu = wiringPiI2CSetup(0x68);
    if(wiringPiI2CReadReg8(mpu, 0x75) != 0x68)
    {
        printf("Connection fail. \n");
        exit(1);
    }
    initMpu();
    while(1)
    {
        tempBin = wiringPiI2CReadReg8(mpu, 0x41);
        tempBin = tempBin<<8 | wiringPiI2CReadReg8(mpu, 0x42);
        tempC = convertB2D(tempBin);
        tempC = tempC/340 + 36.53;
        display_float(tempC, 2);
        printf("Nhietdo:%.3f",tempC);
        delay(1000);
    }
    return 0;
}