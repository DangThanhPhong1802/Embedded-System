#include <wiringPiSPI.h>
#include <stdio.h>
#include <stdint.h>

#define spi0 0
uint8_t buf[2];

void sendData(uint8_t address, uint8_t data){
    buf[0] = address;
    buf[1] = data;
    wiringPiSPIDataRW(spi0, buf, 2);
}

void Init(void){
    //set decode mode : ox09FF
    //buf[0] = 0x09;
    //buf[1] = 0xFF;
    //wiringPiSPIDataRW(spi0, buf, 2);
    sendData(0x09, 0x00);
    //Set intensity : 0x0A09
    //buf[0] = 0x0A;
    //buf[1] = 0x09;
    //wiringPiSPIDataRW(spi0, buf, 2);
    sendData(0x0A, 0x09);
    //scan limit : 0x0B07
    sendData(0x0B, 0x07);
    //no shutdown, turn off display test
    sendData(0x0C, 1);
    sendData(0x0F, 0);
}

int main(void){
    //setup SPI interface
    wiringPiSPISetup(spi0, 10000000);
    //set operational mode for max7219
    Init();
    //display student ID
    uint8_t mssv[8] = {78,29,28,16,61,0,48,123};
    for(int i=0; i<8; i++){
        sendData(i+1, mssv[7-i]);
    }
    return 0;
}