#include <stdio.h>
#include <stdint.h>
#include <wiringPi.h>
#include <wiringPiSPI.h>

#define spi0 0

void sendData(uint8_t address, uint8_t data){

}

void Init(void){
    //Decode Mode

    
    //Intensity


    //Scan Limit


    //No Shutdown - Turn Off Display


}

void Display_Number(int32_t num){
    //count the number of digits
    uint8_t count=1;
    uint32_t n = num;
    while(n/10){
        count++;
        n = n/10;
    }

    //Scan Limit
    sendData(0x0B, count-1);

    //Display Number
    for(int i=0; i<count; i++){
        sendData(i+1, num%10);
        num = num/10;
    }

}

void Translate(void){

}