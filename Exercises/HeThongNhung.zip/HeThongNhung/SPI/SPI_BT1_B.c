#include <stdio.h>
#include<stdint.h>
#include<wiringPi.h>
#include<wiringPiSPI.h>

#define spi0 0
#define spi_speed 1000000
unsigned char data[2];
uint8_t covid[9]={0x4E,0x7E,};
void SendData(unsigned char address,unsigned char value){
    
    data[0]= address;
    data[1]=value;
    wiringPiSPIDataRW(spi0,data,2);
}
void Init(void){
    // set decode mode : 0x09FF
    SendData(0x09,0xFF); // 0xFF : la hien so
                         // 0x00 : la hien chu 
    // set intensity : 0x0A09
    SendData(0x0A,9);
    // set scan_limit : 0x0B07
    SendData(0x0C,1);
    SendData(0x0F,0);
}
int main(){
    wiringPiSPISetup(spi0,spi_speed);
    // set operational mode for max7219
    Init();
    // display number student ID
    uint8_t mssv[8]={2,0,1,4,6,0,3,7};
    // binary covid 19
    uint8_t covid[8] = {78,29,28,16,61,0,48,123};
    for(int i=0;i<8;i++)
    {
        SendData(i+1,mssv[8-i]);
    }
    
    return 0;
}