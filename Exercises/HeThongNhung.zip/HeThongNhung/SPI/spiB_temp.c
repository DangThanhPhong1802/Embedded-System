#include <stdio.h>
#include<stdint.h>
#include<wiringPi.h>
#include<wiringPiSPI.h>
#include<stdlib.h>


#define spi0 0
#define spi_speed 1000000
unsigned char data[2];
float temp,temp1;
uint8_t digit[8] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};

void SendData(unsigned char address,unsigned char value){
    data[0]= address;
    data[1]=value;
    wiringPiSPIDataRW(spi0,data,2);
}
void Init(void){
    // set decode mode : 0x09FF
    SendData(0x09,0xFF);
    // set intensity : 0x0A09
    SendData(0x0A,0x07);
    SendData(0x0B,7);
    // set scan_limit : 0x0B07
    SendData(0x0C,1);
    SendData(0x0F,0);
    
}
int main(){
    wiringPiSetup();
    wiringPiSPISetup(spi0,spi_speed);
    // set operational mode for max7219
    Init();
    // display tenparature CPU
      // get temperature CPU
        delay(200);
    FILE* fp=fopen("/sys/class/thermal/thermal_zone0/temp", "r");   
    if(fp==NULL) {
        printf("Error : Can't open file CPU ");
    }
    // show temperature of CPU in terminal
    fscanf(fp,"%f",&temp);
    fclose(fp);

    char temp_str[8];
    snprintf(temp_str,sizeof(temp_str),"%f",temp);
    temp1=temp/1000;
    printf("Nhiet do CPU: %.2f\n",temp1);    
    
    }