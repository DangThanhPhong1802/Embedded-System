#include "max7219_lib.h"
int mang_chuye_doi[12] = {0x7E, 0x30, 0x6D, 0x79, 0x33, 0x5B, 0x5F, 0x70,0x7F,0x7B, 0x63,0x4E};
void sendData(uint8_t address, uint8_t data){
    buf[0] = address;
    buf[1] = data;
    wiringPiSPIDataRW(spi0, buf, 2);
}
int16_t readSensor(uint8_t address){
    high = wiringPiI2CReadReg8(mpu,address);
    low = wiringPiI2CReadReg8(mpu,address+1);
    value = ((high<<8)|low);
    return value; 
}
void dataReady(void){
	// clear interrupt flag
	wiringPiI2CReadReg8(mpu, 0x3A);
	// read sensor data
	
}
void initMpu(void){
    // sample rate 100Hz  
    wiringPiI2CWriteReg8(mpu,0x19,9);
    // DLPF : 44 
    wiringPiI2CWriteReg8(mpu,0x1A,0x03);
    // Gygro Congiuration +500
    wiringPiI2CWriteReg8(mpu,0x1B, 0x08);
    // Acc Configuration +-8g
    wiringPiI2CWriteReg8(mpu,0x1C, 0x10);
    // Interrupt
    wiringPiI2CWriteReg8(mpu,0x38, 1);
    // power management
    wiringPiI2CWriteReg8(mpu,0x6B, 1);
}
void InitSPI(void){
    // no shutdown, no display test
    sendData(0x0C, 0x01);
    sendData(0x0F, 0x00);
    // scan limit 0x0B07
    sendData(0x0B, 7);
    // set intensity
    sendData(0x0A, 0x03);
    // No decode mode 
    sendData(0x09, 0x00);
}
void temp_process(float temp,int startpos ){
    covert_vl = temp*100 ;
    tp1 = covert_vl%10;
    tp2 = (covert_vl/10)%10;
    pn1 = (covert_vl/100)%10;
    pn2 = covert_vl/1000 ; 
    sendData((startpos)%8+1,mang_chuye_doi[11]);
    sendData((startpos+1)%8+1,mang_chuye_doi[10]);
    sendData((startpos+2)%8+1,mang_chuye_doi[tp1]);
    sendData((startpos+3)%8+1,mang_chuye_doi[tp2]);
    sendData((startpos+4)%8+1,mang_chuye_doi[pn1]+0x80);
    sendData((startpos+5)%8+1,mang_chuye_doi[pn2]);
    sendData((startpos+6)%8+1,0);
    sendData((startpos+7)%8+1,0);
}
int main (void){
wiringPiSetup();
wiringPiSPISetup(spi0, 1000000);
// setup i2c interface
mpu = wiringPiI2CSetup(0x68);
// configuration mpu6000
who = wiringPiI2CReadReg8(mpu,0x75);
// check connection 
if(who!= 0x68){printf("Connect Falily\n");
	exit(1);}
initMpu();
InitSPI();
// setup interrupt for INT pin
pinMode(INT_pin, INPUT);
wiringPiISR(INT_pin, INT_EDGE_RISING, &dataReady);

//sendData(1,0x06);
//sendData(0,0);
//muiten();
while(1){
    //printf("Start calculated:\n");
    //sendData(0,0xff);
    //temp = readSensor(0x41);
    //temp = temp/340.0+36.53;
    //temp_process(temp);
    //printf("Nhiet do: %f\n",temp);
    //delay(2000);
}
return 0 ;}
