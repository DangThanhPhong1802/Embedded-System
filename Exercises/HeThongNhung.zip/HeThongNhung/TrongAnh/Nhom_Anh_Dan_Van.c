// Bài kiểm tra 1 
// Nhóm :
//   Đỗ Trọng Anh -20146474
//   Nguyễn Hữu Dân - 20146484
//   Lê Thanh Vân - 20146160 
// Khai báo thư viện 
#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
// Khai báo các chân GPIO
#define red 2 //pin 11
#define green 0 // pin13
#define blue 3 // pin15
#define bt1 22 // pin31
#define bt2 23 // pin33
#define bt3 24 // pin35
#define bt4 25 // pin37
// Tạo mảng để chứa các giá trị GPIO
uint8_t kiem_tra_value ;
uint8_t  led[3] = {2,0,3};
uint8_t  btn[3] = {22,23,24};
uint8_t  color[3] ;
uint8_t  chuyen_mau[10][3] = {{100,0,0},{0,100,0},{0,0,100}
                            ,{100,100,0},{0,100,100},{100,0,100}
                            ,{100,100,100}
                            }; 
int state = 0 ;
int state_dk =0;
int r,g,b,option;
int dem =0 ;
int tan_so;
// Hàm tính giá trị màu hiện tại được nhập ở chế độ 1 
void kiem_tra(){
    for(int i=0;i<10;i++){
        if((color[0]==chuyen_mau[i][0])&&(color[1]==chuyen_mau[i][1])&&(color[2]==chuyen_mau[i][2])){kiem_tra_value=i;}   
    } 
}
// Chế độ 1 
void che_do1(void){
    softPwmWrite(led[0],color[0]);
    softPwmWrite(led[1],color[1]);
    softPwmWrite(led[2],color[2]);        
}
// Option2 trong chế độ 2 
void option2(void){

    while(dem<8){
        softPwmWrite(led[0],chuyen_mau[kiem_tra_value][0]); // xung la 100 neu chia 20% la 5 
        softPwmWrite(led[1],chuyen_mau[kiem_tra_value][1]);
        softPwmWrite(led[2],chuyen_mau[kiem_tra_value][2]);
        kiem_tra_value++;
        if(kiem_tra_value==7){kiem_tra_value=0;}
        dem++ ; 
        delay(1000/(8*tan_so));
    }
}
// option 1 trong chế độ 2 
void option1(void){

    for(float j=0;j<1;j=j+0.1) 
{       softPwmWrite(led[0],chuyen_mau[kiem_tra_value][0]*j); // xung la 100 neu chia 20% la 5 
        softPwmWrite(led[1],chuyen_mau[kiem_tra_value][1]*j);
        softPwmWrite(led[2],chuyen_mau[kiem_tra_value][2]*j);
        delay(1000/(2*tan_so));
}
    for(float j=1;j>=0;j=j-0.1)
{
        softPwmWrite(led[0],chuyen_mau[kiem_tra_value][0]*j); // xung la 100 neu chia 20% la 5 
        softPwmWrite(led[1],chuyen_mau[kiem_tra_value][1]*j);
        softPwmWrite(led[2],chuyen_mau[kiem_tra_value][2]*j);
        delay(1000/(2*tan_so));
}
    softPwmWrite(led[2],chuyen_mau[kiem_tra_value][2]*0);
    softPwmWrite(led[1],chuyen_mau[kiem_tra_value][1]*0);
    softPwmWrite(led[0],chuyen_mau[kiem_tra_value][0]*0);
}
// Lưu giá trị màu vừa nhập vào 1 mảng color
void setColor(int r, int g, int b) {
    color[0] = r;
    color[1] = g;
    color[2] = b;
}
void interrupt_bt1(void){state = 1 ;}
void interrupt_bt2(void){
    state= 2;
// Set trạng thái khi nhấn nút nhấn 2 
    if ((digitalRead(bt2)==1)&&(state_dk==0)) {state_dk=1 ;}
    if ((digitalRead(bt2)==0)&&(state_dk==1)) {state_dk=2;}
    if ((digitalRead(bt2)==1)&&(state_dk==3)) {state_dk=4;}
    if ((digitalRead(bt2)==0)&&(state_dk==4)) {state_dk=5;}
     }
int main(void)
{
// Set up function cho các chân
    wiringPiSetup();
    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }
    for(int i=0; i<3; i++){
        pinMode(btn[i],1);
    }
    wiringPiISR(bt1, INT_EDGE_BOTH, &interrupt_bt1);
    wiringPiISR(bt2, INT_EDGE_BOTH, &interrupt_bt2);
    printf("Start\n");
while(1){
    while(state==1){printf("Che do 1\n");
    printf("Nhap gia tri: r g b \n");
    scanf("%d %d %d", &r, &g, &b);
    setColor(r,g,b);
    che_do1();
    kiem_tra();
    //printf("phan tu thu %d\n",kiem_tra_value);
    state =0 ;
    }
    while(state ==2){//printf("Che do 2\n");
    if (state_dk==2) { printf("Chon 1 trong 2 option: \n");scanf("%d", &option);state_dk=3;}
    if (state_dk==5) { printf("Nhap tan so : \n");scanf("%d", &tan_so);state_dk=6;}
    while((option==1)&&(state_dk==6)){option1();}
    while((option==2)&&(state_dk==6)){option2();dem=0;}
    }
    }
return 0 ;}