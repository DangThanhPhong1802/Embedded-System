#include <wiringPiI2C.h>
#include <wiringPiSPI.h>
#include <wiringPi.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#define INT_pin  7
uint8_t who;
uint8_t low,high;
int16_t value ;
uint8_t buf[2];
int mpu ;
float accel_x,accel_y,accel_z;
float x_goc, y_goc,z_goc ;
float yaw, pitch ,roll ;
float sinyaw , cosyaw ;
float gyro_value ;
float past_gyro , cur_gyro ;
float readSensor(unsigned char address){
    high = wiringPiI2CReadReg8(mpu,address);
    low = wiringPiI2CReadReg8(mpu,address+1);
    value = ((high<<8)|low);
    return value; 
}
float gyro(float angle, float gyro1 , float gyro2){
    return angle + 0.5*(gyro1+gyro2)*0.1 ;
}
void dataReady(void){
	// clear interrupt flag
	wiringPiI2CReadReg8(mpu, 0x3A);
	// read sensor data
	
}
void initMpu_accel(void){
    // sample rate 100Hz  
    wiringPiI2CWriteReg8(mpu,0x19,9);
    // DLPF : 44 
    wiringPiI2CWriteReg8(mpu,0x1A,0x02);
    // Gygro Congiuration +500
    wiringPiI2CWriteReg8(mpu,0x1B, 0x08);
    // Acc Configuration +-8g
    wiringPiI2CWriteReg8(mpu,0x1C, 0x10);
    // Interrupt
    wiringPiI2CWriteReg8(mpu,0x38, 1);
    // power management
    wiringPiI2CWriteReg8(mpu,0x6B, 1);
}
int main (void){
wiringPiSetup();
// setup i2c interface
mpu = wiringPiI2CSetup(0x68);
// configuration mpu6000
who = wiringPiI2CReadReg8(mpu,0x75);
// check connection 
if(who!= 0x68){printf("Connect Falily\n");
	exit(1);}
initMpu_accel();
// setup interrupt for INT pin
pinMode(INT_pin, INPUT);
wiringPiISR(INT_pin, INT_EDGE_RISING, &dataReady);

while(1){
   // printf("Start calculated:\n");
    //temp = readSensor(0x41);
    accel_x =   (float)readSensor(0x3B)/4096;
    accel_y =   (float)readSensor(0x3D)/4096;
    accel_z =   (float)readSensor(0x3F)/4096;
    pitch   =   atan2(accel_x,sqrt(pow(accel_y,2)+pow(accel_z,2)))*180.0/3.14;
    roll    =   atan2(accel_y,sqrt(pow(accel_x,2)+pow(accel_z,2)))*180.0/3.14;
    yaw     =   atan2(accel_z,sqrt(pow(accel_x,2)+pow(accel_y,2)))*180.0/3.14;
    past_gyro = (float)readSensor(0x47)/65.5;
    if(past_gyro != cur_gyro){
        gyro_value =  gyro(yaw, past_gyro , cur_gyro);}
    else{ cur_gyro= (float)readSensor(0x47)/65.5;}
    //yaw = atan2(sin(roll) * cos(pitch), cos(roll) * cos(pitch))*180.0/3.14;
    //accel_z =   (float)readSensor(0x3F);
   // delay(1000);
    //printf("low: %d\n",low);
   // printf("goc z: %f\n",accel_z);
    printf("goc pitch: %0.2f\n",gyro_value);
    printf("goc roll: %0.2f\n",roll);
    printf("goc yaw: %f\n",yaw);
    //printf("gia toc y: %f\n",accel_y/4096);
    //printf("gia toc x: %f\n",accel_x/4096);
}
return 0 ;}