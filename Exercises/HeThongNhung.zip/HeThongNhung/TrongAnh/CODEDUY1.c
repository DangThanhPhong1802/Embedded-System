#include <stdio.h>
#include <stdint.h>
#include <softPwm.h>
#include <wiringPi.h>
#include <stdlib.h>

#define r 13
#define g 11
#define b 15
#define bt1 37
#define bt2 35

// Biến khởi tạo độ sáng đèn (dangj PWM)
uint8_t do_sang =0;
// Khởi tạo biến trạng thái state
int state=0;
// Khởi tạo mảng chứa dãy led
uint8_t LED[3] = {r,  g, b };
int i ;
int n=0;
int dem;
void ngat_bt1(void)
{ 
    
    // Nếu nhấn nút 1 thì độ sáng tăng lên 10 mặc định ban đầu là độ sáng bằng 40
    if(digitalRead(bt1))
    {  
        
        do_sang += 10;
        printf("raspberrypi \n");
        
        
    }
}
    // Chuyển sang 2 chế độ nhờ button 2: thay đổi biến trạng thái state
    // Đều lấy giá trị logic bt2  = 1 vì mình để ở lấy cả hai sườn cạnh lên và xuống
    //nên khi có sự kiện ngắt, nó sẽ lấy sườn lên đầu tiên và nếu bỏ ra là sườn xuống nó cũng vẫn ở hàm ngắt
    //Chứ nếu mà bỏ bt_2 = 1 và bt_2 = 0 thì khi nhấn nó để state = 1, khi bỏ ra nó về state = 0
void ngat_bt2(void) 
{
    

    if((digitalRead(bt2)) && (state == 0))
    {
        state = 1;
    }
    else if((digitalRead(bt2))&& (state == 1))
    {
        state = 0;
    }

}

int main(void)
{
    
    wiringPiSetupPhys();
    // Tạo PWM mềm cho 3 kênh led và khai báo nút nhấn
    
    pinMode (r, OUTPUT) ;
    pinMode (g, OUTPUT) ;
    pinMode (b, OUTPUT) ;
    
    softPwmCreate (r, 0, 100);
    softPwmCreate ( g, 0, 100);
    softPwmCreate (b, 0, 100);

    pinMode (bt1, INPUT) ;
    pinMode (bt2 , INPUT);

    // Khởi tạo interrupt nút nhấn 
    wiringPiISR(bt1, INT_EDGE_BOTH, &ngat_bt1);
    wiringPiISR(bt2 , INT_EDGE_BOTH, &ngat_bt2);


    while(1)
    {
        // Trạng thái khi nút nhấn 2 mặc định là 0, Trạng thái 0 đèn nhấp nhấy với tần số 3Hz
        if(state == 0)
        {           
            // Vì tần số là 3Hz nên 1s sẽ có 3 lần chớp và tắt suy ra có 6 trạng thái, ta lấy 1000ms / 6 = 166.667 ms làm tròn thành 167ms

            
            dem = rand()%3;

            
           softPwmWrite(LED[dem], do_sang);
            delay(167);
           softPwmWrite(LED[dem], 0);
            delay(167);
        }

        // Trạng state = 1, thì nó sẽ chạy theo led, ví dụ dãy led là {R, G, B, Y} = {1,0,0,0} -> {0,1,0,0} -> {0,0,1,0} -> {0,0,0,1}
        // Nó cũng sẽ quét chớp tắt lần lượt 

        //if (state==1)

        
        else  
        {
            for(int i = 0; i < 3; i++)
            {
                // Để cho nó sáng led đó và nó tắt led vừa mới sáng
                // Ví dụ sáng led 1 xong sáng led 2 nó sẽ tắt led 1
                pwmWrite(LED[i--], 0);
                pwmWrite(LED[i], do_sang);
                delay(500);
            }
        }
    }    
}