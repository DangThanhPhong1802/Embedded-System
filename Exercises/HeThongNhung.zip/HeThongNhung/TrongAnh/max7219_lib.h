#include <wiringPiI2C.h>
#include <wiringPiSPI.h>
#include <wiringPi.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#define INT_pin  7
#define spi0    0
uint8_t who;
uint8_t low,high;
uint16_t value ;
uint8_t buf[2];
float temp;
int mpu ;
int covert_vl ;
int tp1,tp2;
int pn1,pn2;
float temp,accel_x,accel_y,accel_z;
float x_goc, y_goc,z_goc ;
float yaw, pitch ,roll ;
void initMpu(void);
    // Init MPU with f = 100Hz
    // DLPF = 44 
    // Gygro Congiuration +500
    // Acc Configuration +-8g
    // Interrupt
    // power management

void InitSPI(void);
    // no shutdown, no display test
    // scan limit 0x0B07
    // set intensity
    // No decode mode 

int16_t readSensor(uint8_t address) ;
    // read value register on address 
void dataReady(void);
    // clear interrupt flag
    // read sensor data

void temp_process(float temp,int startpos);
    // enter a float value and this function will display its on max7219
    // the display with 2 number right of the comma

