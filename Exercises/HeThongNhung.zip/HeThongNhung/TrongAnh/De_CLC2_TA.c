#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

#define red 2 //pin 11
#define green 0 // pin13
#define blue 3 // pin15
#define bt1 22 // pin31
#define bt2 23 // pin33
#define bt3 24 // pin35
#define bt4 25 // pin37

#define VN (+7)
time_t rawtime;
struct tm *info;
uint8_t  led[3] = {2,0,3};
uint8_t  btn[3] = {22,23,24};
uint8_t  chuyen_mau[10][3] = {{100,0,0},{0,100,0},{0,0,100}
                            ,{100,100,0},{0,100,100},{100,0,100}
                            ,{100,100,100},{50,0,100},{0,50,100}
                            ,{100,50,50}}; 
uint8_t  color[3] ;  
float  duty = 0.1;
u_int8_t valueRandom;
int r,g,b;
int hour,min;
clock_t start_t, end_t, total_t;
double diff_t;
int GetRandom(int min,int max){
    return min + (int)(rand()*(max-min+1.0)/(1.0+RAND_MAX));
}
void che_do2(int i,float duty){
    for(int j=0 ; j<3; j++){
        softPwmWrite(led[0],duty*chuyen_mau[i][0]);
        softPwmWrite(led[1],duty*chuyen_mau[i][1]);
        softPwmWrite(led[2],duty*chuyen_mau[i][2]);  
    }
}
void che_do1(float duty){
    softPwmWrite(led[0],duty*color[0]);
    softPwmWrite(led[1],duty*color[1]);
    softPwmWrite(led[2],duty*color[2]);        
}
void setColor(float duty ,int r, int g, int b) {
    color[0] = duty*r;
    color[1] = duty*g;
    color[2] = duty*b;
}
void getTime(void){
    time(&rawtime);
    /* Get GMT time */
    info = gmtime(&rawtime );
}
int main(void)
{
    wiringPiSetup();
    getTime();
    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }

    printf("Tại VN: %2d:%02d\n", (info->tm_hour+VN)%24, info->tm_min);
    
    while(1){
    printf("Nhap gia tri: dosang r g b \n");
    scanf("%f %d %d %d",&duty, &r, &g, &b);
    setColor(duty,r,g,b);
    //////////////////////////////////////////////////
    printf("Nhap thoi gian OFF:\n");
    scanf("%d:%d",&hour, &min);
    while(((info->tm_hour+VN)%24!=hour)||(info->tm_min!=min)){
        getTime();
        printf("%d\n",info->tm_min);
//-----------------------------------------------------------
       for(int i=0;i<3;i++){
         softPwmWrite(led[i],color[i]);
        }
        delay(2000);
//----------------------------------------------------------
for (int i=0 ; i<10;i++){
    for(int j =0; j<10;j++){
        getTime();
        if(((info->tm_hour+VN)%24==hour)&&(info->tm_min==min)){j=11;i=11;}
        che_do2(i,j/10.0);
        duty = duty+0.1 ;
        if(duty>1) duty =0;
        delay(100+GetRandom(0,50));} 

    for(int j =9; j>=0;j--){
        if(((info->tm_hour+VN)%24==hour)&&(info->tm_min==min)){j=0;i=11;}
        che_do2(i,j/10.0);
        duty = duty-0.1 ;
        if(duty<0) duty =1;
        delay(100+GetRandom(0,50));}
}
    }}
    return 0;
}