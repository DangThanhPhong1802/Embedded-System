// Khai bao thu vien 
#include <stdio.h>
#include <stdint.h>
#include <softPwm.h>
#include <wiringPi.h>
#include <time.h>
#include <stdlib.h>
// Khai bao chan GPIO
#define led_1 11
#define led_2 13
#define led_3 15 
#define BT_3 33
#define BT_2 31
#define BT_1 37 
// Luu cac gia tri vao trong mang
uint8_t  led[3] = {led_1,led_2,led_3};
uint8_t  btn[3] = {BT_1,BT_2,BT_3};
// Khoi tao mang chua cac gia tri mau 
// Mang khoi tao la mang 2 chieu voi moi phan tu la mang 1 chieu 
// Moi mang 1 chieu dac trung cho 1 gia tri mau 
uint8_t  chuyen_mau[7][3] = {{100,0,0},{0,100,0},{0,0,100}
                            ,{100,100,0},{0,100,100},{100,0,100}
                            ,{100,100,100}}; 
// Khoi tao cac bien trang thai
int random_value;
int che_do,duty;
int color=0 ;
// Khoi tao cac bien dem thoi gian 
// Voi start_t : thoi gian bat dau 
//     end_t   : thoi gian ket thuc 
//     diff = start_t - end_t 
time_t start_t, end_t;
time_t start2_t, end2_t;
double diff_t, diff_t2;
//----------------Ham random gia tri----------------------------
int GetRandom(int min,int max){
    return min + (int)(rand()*(max-min+1.0)/(1.0+RAND_MAX));
}
// Tat tat ca cac led 
void tat_led(void){
    softPwmWrite(led[0],0);
    softPwmWrite(led[1],0);
    softPwmWrite(led[2],0); }
// Cho led xanh la sang voi do sang 50% 
void interrupt_bt1(void)
{  
    softPwmWrite(led[0], 0);
    softPwmWrite(led[1], 50);
    softPwmWrite(led[2], 0);
}
// ----------------------Ham interrupt cho cac button ---------------------------------------
void interrupt_bt2(void)
{   
// Dua ve che do random so 
    if((digitalRead(BT_2)==1)&&(che_do!=2)&&(che_do!=3)){che_do=1;}

}
void interrupt_bt3(void)
{   
// Bat dau dem thoi gian 
    if(digitalRead(BT_3)==1){time(&start_t);diff_t=0;}
// Neu do dang chop tat (che do =2)
//Nhan giu button 3 trong 4 giay de tat 
    while((digitalRead(BT_3)==1)&&(diff_t<4)&&(che_do==2))
{
        time(&end_t);
        time(&start2_t);
        diff_t = difftime(end_t, start_t);
        if(diff_t>=4){che_do=0;printf("RESET!!!");tat_led();} 
        printf("Thời gian thực thi = %f\n", diff_t);
}
// Neu do dang chuyen mau (che do =3)
//Nhan giu button 3 trong 2 giay de tat
    while((digitalRead(BT_3)==1)&&(diff_t<2)&&(che_do==3))
{
        time(&end_t);
        diff_t = difftime(end_t, start_t);
        if(diff_t>=2){che_do=0;printf("RESET!!!");tat_led();} 
        printf("Thời gian thực thi = %f\n", diff_t);
}
  
// LED do chop tat voi tan so 4 Hz
//------------------------------------------
}
void blink_led(void){
    softPwmWrite(led[0],80);
    softPwmWrite(led[1],0);
    softPwmWrite(led[2],0);
    delay(125);
    softPwmWrite(led[0],0);
    softPwmWrite(led[1],0);
    softPwmWrite(led[2],0);
    delay(125);
}
// Che do chuyen mau (7 mau)
void che_do_chuyen_mau(void){
    softPwmWrite(led[0], chuyen_mau[color][0]);
    softPwmWrite(led[1], chuyen_mau[color][1]);
    softPwmWrite(led[2], chuyen_mau[color][2]);
    color = color+1;
    if(color==7){color=0;}
    delay(200);
}
//-----------------------------------------------------
int main(void)
{
    wiringPiSetupPhys();
//------------Khai bao ouput va chan pwm tuong ung ------------------
    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);}
//-------------Khai bao input cho button-------------------------
    for(int i=0; i<3; i++){
        pinMode(btn[i],1);}
//-------------Khai bao interrupt-------------------------------
    wiringPiISR(BT_1, INT_EDGE_BOTH, &interrupt_bt1);
    wiringPiISR(BT_2, INT_EDGE_BOTH, &interrupt_bt2);
    wiringPiISR(BT_3, INT_EDGE_BOTH, &interrupt_bt3);
//----------------------------------------------------------------
while (1)
{
//------ Thuc thi che do 1 (random gia tri)------------------------
    while (che_do==1){
        random_value = GetRandom(20,100); // Tra ve gia tri tu 20->100
        printf("%d\n",random_value);      // Xuat gia tri nhan dc ra man hinh
        delay(2000);
// Neu gia tri random<80 tang giam do sang cua led voi tan so 1Hz
        if (random_value<=80){
            for (duty= 0;duty< 100 ; duty=duty+10){
                softPwmWrite(led[1],duty);
                delay(50);}
            for (duty= 90;duty>= 0 ; duty=duty-10){
                softPwmWrite(led[1],duty);
                delay(50);}}
// Neu gia tri random >80 bat che do 2(led do chop tat voi tan so 4Hz)
        else{
            che_do=2;
            diff_t2=0 ;
            time(&start2_t);
            printf("WARNING!\n");}}
//--------------------Che do nhap nhay led do tan so 4Hz----------------------------------
    while(che_do==2) {
        blink_led();
        time(&end2_t);
        diff_t2 = difftime(end2_t, start2_t);
        if(diff_t2>=4){che_do=3;printf("LED CHUYEN MAU!!");}
        printf("Thời gian thực thi led= %f\n", diff_t2);}
//-------------------------Che do chuyen mau-----------------------------------
    while (che_do==3){che_do_chuyen_mau();}}
        
}
