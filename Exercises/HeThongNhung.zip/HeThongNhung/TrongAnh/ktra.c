#include <wiringPiI2C.h>
#include <wiringPiSPI.h>
#include <wiringPi.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#define INT_pin  7
#define spi0    0
uint8_t who;
uint8_t low,high;
int16_t value ;
uint8_t buf[2];
int mpu ;
float accel_x,accel_y,accel_z;
float x_goc, y_goc,z_goc ;
float yaw, pitch ,roll ;
float sinyaw , cosyaw ;
float gyro_value ;
float past_gyro , cur_gyro ;
int mangy[9] = {0x01,0x02,0x04,0x08,0x0A,0x20,0x40,0x80,0x00 };
float readSensor(unsigned char address){
    high = wiringPiI2CReadReg8(mpu,address);
    low = wiringPiI2CReadReg8(mpu,address+1);
    value = ((high<<8)|low);
    return value; 
}
void sendData(uint8_t address, uint8_t data){
    buf[0] = address;
    buf[1] = data;
    wiringPiSPIDataRW(spi0, buf, 2);
}
void dataReady(void){
	// clear interrupt flag
	wiringPiI2CReadReg8(mpu, 0x3A);
	// read sensor data
}
void initMpu_accel(void){
    // sample rate 500Hz  
    wiringPiI2CWriteReg8(mpu,0x19,1);
    // DLPF : 44 
    wiringPiI2CWriteReg8(mpu,0x1A,0x03);
    // Gygro Congiuration +-250
    wiringPiI2CWriteReg8(mpu,0x1B, 0x00);
    // Acc Configuration +-4g
    wiringPiI2CWriteReg8(mpu,0x1C, 0x08);
    // Interrupt
    wiringPiI2CWriteReg8(mpu,0x38, 1);
    // power management
    wiringPiI2CWriteReg8(mpu,0x6B, 1);
}
void InitSPI(void){
    // no shutdown, no display test
    sendData(0x0C, 0x01);
    sendData(0x0F, 0x00);
    // scan limit 0x0B07
    sendData(0x0B, 7);
    // set intensity
    sendData(0x0A, 0x03);
    // No decode mode 
    sendData(0x09, 0x00);
}
void hien_thi_giua(float any){
    int dem=8 ;

    if(any>20){dem =5 ;}
    if(any>50){dem =6 ;}
    if(any>80){dem =7 ;}
    if(any<-20){dem =2 ;}
    if(any<-50){dem =1 ;}
    if(any<-80){dem =0 ;}
if((dem==5)&&(dem==2)){
    sendData(5,0x18+mangy[dem]);
    sendData(4,0x18+mangy[dem]);}
if(dem==6){
    sendData(5,0x18+mangy[dem]+mangy[dem-1]);
    sendData(4,0x18+mangy[dem]+mangy[dem-1]);}   
if(dem==7){
    sendData(5,0x18+mangy[dem]+mangy[dem-1]+mangy[dem-2]);
    sendData(4,0x18+mangy[dem]+mangy[dem-1]+mangy[dem-2]);} 
if(dem==1){
    sendData(5,0x18+mangy[dem]+mangy[dem+1]);
    sendData(4,0x18+mangy[dem]+mangy[dem+1]);}  
if(dem==0){
    sendData(5,0x18+mangy[dem]+mangy[dem+1]+mangy[dem+2]);
    sendData(4,0x18+mangy[dem]+mangy[dem+1]+mangy[dem+2]);} 
if(dem==8){
     sendData(5,0x18);
    sendData(4,0x18);
}}

void pitch_ic(float anx, float any){
    for(int i = 6 ; i<9; i++){
    sendData(i,0);}
    for(int i = 3 ; i>0; i--){
    sendData(i,0);}
    if(anx> 20 ){sendData(6,0x18);}
    if(anx>50){sendData(7,0x18);}
    if(anx>80){(sendData(8,0x18));}
    if(anx<-20 ){sendData(3,0x18);}
    if(anx<-50){sendData(2,0x18);}
    if(anx<-80){sendData(1,0x18);}
}
int main (void){
wiringPiSetup();
wiringPiSPISetup(spi0, 1000000);
// setup i2c interface
mpu = wiringPiI2CSetup(0x68);
// configuration mpu6000
who = wiringPiI2CReadReg8(mpu,0x75);
// check connection 
if(who!= 0x68){printf("Connect Falily\n");
	exit(1);}
initMpu_accel();
InitSPI();
// setup interrupt for INT pin
pinMode(INT_pin, INPUT);
wiringPiISR(INT_pin, INT_EDGE_RISING, &dataReady);
for(int i = 1 ; i<9; i++){
    sendData(i,0);
}
printf("Start calculated:\n");
while(1){
    accel_x =   (float)readSensor(0x3B)/8192;
    accel_y =   (float)readSensor(0x3D)/8192;
    accel_z =   (float)readSensor(0x3F)/8192;
    pitch   =   atan2(accel_x,sqrt(pow(accel_y,2)+pow(accel_z,2)))*180.0/3.14;
    roll    =   atan2(accel_y,sqrt(pow(accel_x,2)+pow(accel_z,2)))*180.0/3.14;
    yaw     =   atan2(accel_z,sqrt(pow(accel_x,2)+pow(accel_y,2)))*180.0/3.14;
    hien_thi_giua(roll);
    printf("goc pitch : %0.1f\n", pitch);
    printf("goc rollroll : %0.1f\n", roll);
    pitch_ic(pitch, yaw);
}
return 0 ;}