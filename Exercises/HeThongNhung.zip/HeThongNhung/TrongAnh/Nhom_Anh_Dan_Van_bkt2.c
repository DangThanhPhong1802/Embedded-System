#include <wiringPiI2C.h>
#include <wiringPiSPI.h>
#include <wiringPi.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#define INT_pin  7
#define spi0    0
float accel_x, accel_y,accel_z;
float pitch , yaw , roll ;
uint8_t who;
uint8_t low,high;
int16_t value ;
uint8_t buf[2];
float temp;
int mpu ;
int covert_vl ;
int tp1,tp2;
int pn1,pn2;
int bien_huong ; 
int trangthai_copxe_st ;
float v =0 ;
int mang_chuye_doi[13] = {0x7E, 0x30, 0x6D, 0x79, 0x33, 0x5B, 0x5F, 0x70,0x7F,0x7B, 0x63,0x4E, 0x01};
int huong[2] = {0x67,0x7E};
int open[3] = {0x7E, 0x67 , 0x15};
int cls[3] = {0x4E,0x0E,0x5B};
void sendData(uint8_t address, uint8_t data){
    buf[0] = address;
    buf[1] = data;
    wiringPiSPIDataRW(spi0, buf, 2);
}
float readSensor(uint8_t address){
    high = wiringPiI2CReadReg8(mpu,address);
    low = wiringPiI2CReadReg8(mpu,address+1);
    value = ((high<<8)|low);
    return value; 
}
void dataReady(void){
	// clear interrupt flag
	wiringPiI2CReadReg8(mpu, 0x3A);
	// read sensor data
	
}
void initMpu_accel(void){
    // sample rate 100Hz  
    wiringPiI2CWriteReg8(mpu,0x19,9);
    // DLPF : 44 
    wiringPiI2CWriteReg8(mpu,0x1A,0x02);
    // Gygro Congiuration +500
    wiringPiI2CWriteReg8(mpu,0x1B, 0x08);
    // Acc Configuration +-8g
    wiringPiI2CWriteReg8(mpu,0x1C, 0x10);
    // Interrupt
    wiringPiI2CWriteReg8(mpu,0x38, 1);
    // power management
    wiringPiI2CWriteReg8(mpu,0x6B, 1);
}
void InitSPI(void){
    // no shutdown, no display test
    sendData(0x0C, 0x01);
    sendData(0x0F, 0x00);
    // scan limit 0x0B07
    sendData(0x0B, 7);
    // set intensity
    sendData(0x0A, 0x03);
    // No decode mode 
    sendData(0x09, 0x00);

    
}
void temp_process(float temp,int startpos , int bien_huong, int trangthai_copxe){
    int value = abs(temp);
    int copxe[2][3] = {{0x7E, 0x67 , 0x15} , {0x4E,0x0E,0x5B}};
    if(value>=10) pn1 = ((int)value)/10;
    else pn1 = 0 ;
    pn2 = (int)value%10 ; 
    sendData((startpos)%8+1,copxe[trangthai_copxe][2]);
    sendData((startpos+1)%8+1,copxe[trangthai_copxe][1]);
    sendData((startpos+2)%8+1,copxe[trangthai_copxe][0]);
    sendData((startpos+3)%8+1,mang_chuye_doi[12]);
    sendData((startpos+4)%8+1,mang_chuye_doi[pn2]);
    sendData((startpos+5)%8+1,mang_chuye_doi[pn1]); //
    sendData((startpos+6)%8+1,mang_chuye_doi[12]); // Dau "-"
    sendData((startpos+7)%8+1,huong[bien_huong]); // D or P
if((trangthai_copxe ==0)&&(v>10)){
delay(50);
for(int i = 1 ; i<9; i++){
    sendData(i,0);
}}
}
int main (void){
wiringPiSetup();
wiringPiSPISetup(spi0, 1000000);
// setup i2c interface
mpu = wiringPiI2CSetup(0x68);
// configuration mpu6000
who = wiringPiI2CReadReg8(mpu,0x75);
// check connection 
if(who!= 0x68){printf("Connect Falily\n");
	exit(1);}
 initMpu_accel();
InitSPI();
// setup interrupt for INT pin
pinMode(INT_pin, INPUT);
wiringPiISR(INT_pin, INT_EDGE_RISING, &dataReady);
for(int i = 1 ; i<9; i++){
    sendData(i,0);
}
printf("Start calculated:\n");
while(1){
    accel_x =   (float)readSensor(0x3B)/4096;
    accel_y =   (float)readSensor(0x3D)/4096;
    accel_z =   (float)readSensor(0x3F)/4096;
    delay(500) ;
    if(abs(abs((float)readSensor(0x3B)/4096) - accel_x) > 0.1 ){bien_huong=1;}
    else{bien_huong = 0; }
   //
    pitch   =   atan2(accel_x,sqrt(pow(accel_y,2)+pow(accel_z,2)))*180.0/3.14;
    if(pitch<=10){trangthai_copxe_st = 1;} // cop xe dong
    else {trangthai_copxe_st = 0 ;}
// Cong thuc tinh van toc 
    v =  v+accel_x*0.5*3.6; 
// neu van toc > 0.2 
    if(v>0.2){bien_huong=1;}
    else{bien_huong =0 ;}

    printf("van toc : %f\n", v); 
    //sendData(0,0xff);
    //temp = readSensor(0x41);
    //temp = temp/340.0+36.53;
    temp_process(pitch,0, bien_huong, trangthai_copxe_st);
    //printf("Nhiet do: %f\n",temp);
    //delay(2000);
    
//************************************************************8
   // printf("Start calculated:\n");
    //temp = readSensor(0x41);

    //temp = temp/340.0+36.53;
    //temp_process(temp);
    //pitch = atan(accel_x/sqrt(pow(accel_y,2)+pow(accel_z,2)));
//    roll    =   atan2(accel_y,sqrt(pow(accel_x,2)+pow(accel_z,2)))*180.0/3.14;
    //yaw     =   atan2(accel_z,sqrt(pow(accel_y,2)+pow(accel_x,2)))*180.0/3.14;
    printf("goc pitch: %0.2f\n", pitch);
    //printf("goc roll: %0.2f\n",roll);
    //printf("gia toc y: %f\n",accel_y/4096);
    //printf("gia toc x: %f\n",accel_x/4096);    

}
return 0 ;}