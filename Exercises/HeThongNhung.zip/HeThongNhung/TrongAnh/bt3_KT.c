#include<stdio.h>
#include<stdint.h>
#include<unistd.h>
#include<wiringPi.h>
#include<stdlib.h>
#include<softPwm.h>

#define red 2
#define green 0
#define blue 3
#define btn1 22
#define btn2 23
#define btn3 24

uint8_t ledpin[3]={2,0,3};
uint8_t btn[3]={22,23,24};
float duty=0;
unsigned int mode=0;
unsigned int state =0;
unsigned int start =0;
unsigned int stop =0;
unsigned int stop_reset =0;
unsigned int start_reset =0;
void led(float duty,unsigned int r,unsigned int g,unsigned int b){
    unsigned int R=0,B=0,G=0;
    R = duty*r;
    G = duty*g;
    B = duty*b;
    softPwmWrite(ledpin[0],R);
    softPwmWrite(ledpin[1],G);
    softPwmWrite(ledpin[2],B);
}
uint8_t mang_mau[11][3]={{100,0,0},{0,100,0},{0,0,100},{100,100,0},{100,0,100},{0,100,100},{100,50,0},{100,0,50}};
unsigned valueRandom=0;
void btn1_ngat(){
    state =1;
}
void btn2_ngat(){
    state =2;
    
}
void btn3_ngat(){
    if((stop-start)<=4000) {
        state =2;
        valueRandom=0;
    }
    start_reset =millis();
}
int main(){
    /* set up wiringPi*/
    wiringPiSetup();
    /* set up GPIO*/
    for(int i=0;i<3;i++){
        pinMode(ledpin[i],0);
        softPwmCreate(ledpin[i],0,100);
    }
    for(int i=0;i<3;i++){
        pinMode(btn[i],1);
    
unsigned int count =0;
    /* set up interrupt*/
    wiringPiISR(btn1,INT_EDGE_BOTH,&btn1_ngat);
    wiringPiISR(btn2,INT_EDGE_BOTH,&btn2_ngat);
    wiringPiISR(btn3,INT_EDGE_BOTH,&btn3_ngat);
    while(1){
        /* led xanh sang voi cuong do 50%*/
        while(state==1){
            led(0.5,0,100,0);
        }
        /* led xanh sang dan, roi tat dan*/
        while(state==2){
            if(valueRandom<=80){
                if((count>0)&&(count<=500)){
                    led(count/10,0,100,0);
                }
                 if((count>500)&&(count<=1000)){
                     led(count/10-0.25,0,100,0);
                }
                 if((count>1000)&&(count<=1500)){
                     led(count/10-0.5,0,100,0);
                }
                 if((count>1500)&&(count<=2000)){
                     led(1-count/10,0,100,0);
                }
            }
            else{
                start =millis();
                state =3;
            }
            if(count==2000){
                valueRandom = rand()%80+20;
                printf("\nGia tri ngau nhien :\n%d",valueRandom);
                count =0;
                fflush(stdout);
            }
            count++;
            delay(1);
        }
        /* che do led do chop tat o tan so 4Hz*/
        while(state==3){
            led(0,100,0,0);
            delay(125);
            led(0.5,100,0,0);
            delay(125);
            printf("\nWarning\n");
            fflush(stdout); //  giai phong vung nho dem
            stop = millis();// lay thoi gian thuc thi 
            if((stop-start)>4000) {
                state =4;
            }
        }
        while(state==4){
            if(mode>7) mode=0;
            mode++;
            led(0.5,mang_mau[mode][0],mang_mau[mode][1],mang_mau[mode][2]);
            delay(500);
             if(digitalRead(btn3)==1){
             stop_reset =millis();
             if((stop_reset-start_reset)>=2000){
                state=2;
                valueRandom =0;
             }
             else {
                start_reset =0;
                stop_reset =0;
             }
        }
        }
       
    }
    }
    return 0;

}