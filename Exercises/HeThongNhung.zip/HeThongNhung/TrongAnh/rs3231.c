#include <wiringPiI2C.h>
#include <wiringPiSPI.h>
#include <wiringPi.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
int mpu ;
#define giay 0x00
#define phut 0x01
#define gio 0x02
int minute,hour,sec;
time_t current_time;
struct tm * time_info;
//***********************************************************
int gettime() {
    time(&current_time);
    time_info = localtime(&current_time);
}
//**********************************************************
int show(uint8_t option){
    uint8_t  high , low ;
    high= (wiringPiI2CReadReg8(mpu,option)>>4);
    low = (wiringPiI2CReadReg8(mpu,option)&0x0F);
    return high*10+low ;
}
//***********************************************************
int main (void){
wiringPiSetup();
// setup i2c interface
mpu = wiringPiI2CSetup(0x68);
//hour = wiringPiI2CReadReg8(mpu,0x02);
printf("hour: %d\n",hour);
gettime();
sec =time_info -> tm_sec;
minute = time_info -> tm_min;
hour =time_info -> tm_hour;
wiringPiI2CWriteReg8(mpu,0x00, sec%10+sec/10*16);
wiringPiI2CWriteReg8(mpu,0x01, minute%10+minute/10*16);
wiringPiI2CWriteReg8(mpu,0x02, hour%10+hour/10*16);
while(1){
    printf("real time : %d:%d:%d\n",show(gio),show(phut),show(giay));
}
return 0 ;}