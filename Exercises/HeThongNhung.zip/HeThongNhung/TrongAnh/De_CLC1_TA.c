
#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

#define red 2 //pin 11
#define green 0 // pin12
#define blue 3 // pin13
#define bt1 22// pin35
#define bt2 23 // pin37
uint8_t  led[3] = {2,0,3};
uint8_t  btn[2] = {bt1,bt2};
u_int8_t color =0;
float  duty = 0.1;
int state=0 ;
time_t start_t, end_t;
double diff_t;
uint8_t  chuyen_mau[10][3] = {{100,0,0},{0,100,0},{0,0,100}
                            ,{100,100,0},{0,100,100},{100,0,100}
                            ,{100,100,100},{50,0,100},{0,50,100}
                            ,{100,50,50}}; 
void interrupt_bt1(void)
{   if(duty>1) duty =0 ;
    if(digitalRead(bt1)==1){
        duty= duty+0.1;
        time(&start_t);
        diff_t=0;}
    while((digitalRead(bt1)==1)&&(diff_t<2)){
        time(&end_t);
        diff_t = difftime(end_t, start_t);
    if(diff_t>=2){duty=0;} 
        printf("Thời gian thực thi = %.2f\n", diff_t);
}
    softPwmWrite(led[0], duty*chuyen_mau[color][0]);
    softPwmWrite(led[1], duty*chuyen_mau[color][1]);
    softPwmWrite(led[2], duty*chuyen_mau[color][2]);
}
void interrupt_bt2(void)
{   
    if(color==10) color =0 ;
    if ((digitalRead(bt2)==1)&&(state==0)) {state=1 ;}
    if ((digitalRead(bt2)==0)&&(state==1)) {state=2;color= color+1;}
    if ((digitalRead(bt2)==1)&&(state==2)) {state=3;}
    if ((digitalRead(bt2)==0)&&(state==3)) {state=0;}
   // printf("%d\n",state);
}
int main(void)
{
    wiringPiSetup();
    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }
    for(int i=0; i<2; i++){
        pinMode(btn[i],1);
    }
    wiringPiISR(bt1, INT_EDGE_BOTH, &interrupt_bt1);
    wiringPiISR(bt2, INT_EDGE_BOTH, &interrupt_bt2);
    while(1){
while(state==2){
    softPwmWrite(led[0], duty*chuyen_mau[color][0]);
    softPwmWrite(led[1], duty*chuyen_mau[color][1]);
    softPwmWrite(led[2], duty*chuyen_mau[color][2]);
    }
while(state==0){
    softPwmWrite(led[0], duty*chuyen_mau[color][0]);
    softPwmWrite(led[1], duty*chuyen_mau[color][1]);
    softPwmWrite(led[2], duty*chuyen_mau[color][2]);
    delay(200);
    softPwmWrite(led[0], 0);
    softPwmWrite(led[1], 0);
    softPwmWrite(led[2], 0);
    delay(200);
    }
    }
    return 0;
    }