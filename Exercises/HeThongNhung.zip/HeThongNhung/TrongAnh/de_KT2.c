//Bai KT1
//Nhom SV:
//     - Ho ten:  Tran Ngoc Hieu   MSSV: 20146127      (ST3)
//     - Ho ten:  Nguyen Ba Vu Thach   MSSV: 20146530  (ST3)
//     - Ho ten:  Le Tan Loc   MSSV: 20146121          (CT3)






#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <wiringPiSPI.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <wiringPiI2C.h>
#include <stdint.h>

#define R 2//11
#define G 0//12
#define B 3//13
#define BT1 22//15
#define BT2 23//16
#define BT3 24//18

unsigned int color[11][3] = {{0, 0, 0},{127, 0, 0}, {0, 127, 0}, {0, 0, 127},
							{127,127,0}	,{127,0,127}, {0,127,127}, {127,127,127},
							{70,120,70}, {150,70,200},{50,50,180} };
							
unsigned int state = 0, num_random = 0, mode = 0;
unsigned int do_sang = 0;
unsigned int start = 0, stop = 0, start_reset = 0, stop_reset = 0; 
	
void led(unsigned int do_sang, unsigned int r, unsigned int g, unsigned int b)
{
	unsigned int rd=0, gd=0, bd=0;
	
	//Tinh toan gi tri r,g,b phu hop voi do sang 0-->20
	//20*5*255/100 = 255 --> Max toi da la 255 khi nhap do sang cap 20
	rd = do_sang*5*r/100; 
	gd = do_sang*5*g/100;
	bd = do_sang*5*b/100;
	
	//Hien thi mau
	//Chuyen do sang tu [0, 255] sang [0, 100] de bo vao ham softPwmWrite
	softPwmWrite(R, rd*100/255); 
	softPwmWrite(G, gd*100/255);
	softPwmWrite(B, bd*100/255);
}
	
void ngatBT1()
{
	state = 1;
}

void ngatBT2()
{
	state = 2;
}	

void ngatBT3()
{
	//Neu Nhan BT3 trong vong 4 giay thi reset he thong
	if ((stop - start) < 4000) 
	{
		state = 2;
		num_random = 0;
	}
	
	start_reset = millis();



}


int main(void)
{
	//Set up wiringPi
	wiringPiSetup();
	//Set up GPIO 
	pinMode(R, OUTPUT);
	pinMode(G, OUTPUT);
	pinMode(B, OUTPUT);

	pinMode(BT1, INPUT);
	pinMode(BT2, INPUT);
	pinMode(BT3, INPUT);

	//Set up PWM
	softPwmCreate(R, 0, 100);
	softPwmCreate(G, 0, 100);
	softPwmCreate(B, 0, 100);
	
	//Set up Interrupt
	wiringPiISR(BT1, INT_EDGE_BOTH, &ngatBT1);
	wiringPiISR(BT2, INT_EDGE_BOTH, &ngatBT2);
	wiringPiISR(BT3, INT_EDGE_BOTH, &ngatBT3);


	//
	unsigned int count = 0;
	while(1)
	{
		//Che do bat led xanh la cay
		while(state == 1)
		{
			//Co 20 cap do sang, chon cap do 10 (50%)
			led(10, 0, 255, 0);
		}
		
		//Che do in so ngau nhien va tang giam do sang led Xanh la cay
		while(state == 2)
		{

			//Neu num < 80
			if (num_random <= 80)  
			{
				//Tang giam do sang voi chu ki 1 giay
				if ((count > 0)&(count <= 500))
				led(count/25, 0, 255, 0);
			
				if ((count > 500)&(count <= 1000))
				led(40 - count/25, 0, 255, 0);
			
				if ((count > 1000)&(count <= 1500))
				led(count/25 - 20, 0, 255, 0);
			
				if ((count > 1500)&(count <= 2000))
				led(80 - count/25, 0, 255, 0);
					
			}
			//Neu num >= 80 thi chuyen qua che do warning
			else 
			{
					start = millis();
					state = 3;
			}
			
			//Moi 2 giay se tao 1 so ngau nhien
			if (count == 2000) 
			{
				//Tao so ngau nhien
				num_random = rand()%80 + 20;
				
				//In ra man hinh
				printf("So ngau nhien: %d\n", num_random);
				fflush(stdout);
				
				//Reset 
				count = 0;
			}

			delay(1);
			count++;
		}
		
		//Che do warning
		while(state == 3)
		{
			//Chop tat LED do voi tan so 4Hz
			led(0, 255, 0, 0);
			delay(125);
			led(16, 255, 0, 0);
			delay(125);
			
			//In ra man hinh canh bao
			printf("\r Warning");
			fflush(stdout);
			
			//Lay goc thoi gian
			stop = millis();
			//Neu sau giay khong co su kien nut nhan thi chuyen qua che do 7 mau
			if ((stop - start) > 4000) state = 4;
	

		}
		
		//Che do 7 mau
		while(state == 4)
		{
			//Thay doi mau
			mode++;
			if (mode > 7) mode = 0;
			//Hien thi mau
			led(10, color[mode][0], color[mode][1], color[mode][2]);
			delay(500);
			
			
			//Reset neu giu BT3 trong 2 giay
			if (digitalRead(BT3) == LOW)
			{
				stop_reset = millis();
				//Neu giu tren 2 giay thi reset
				if ((stop_reset - start_reset) >= 2000)
				{
					state = 2;
					num_random = 0;
				}
			}
			//Neu nhan chua kip 2 giay thi reset bien dem
			else 
			{
				stop_reset = 0;
				start_reset = 0;
			}
		}
		
		
	}
	
	return 0;
}

