#include<stdio.h>
#include<stdint.h>
#include<unistd.h>
#include<softPwm.h>
#include<wiringPi.h>
#include<stdint.h>
#include<stdlib.h>

#define red 2 
#define green 0 
#define blue 3 

#define btn1 22 
#define btn2 23 
#define btn3 24 

uint8_t ledpin[3]={2,0,3};
uint8_t btn[3]={22,23,24};

unsigned int mang_mau[11][3]={{100,0,0},{0,100,0},{0,0,100},{100,100,0},{100,0,100},{0,100,100},{100,100,100}};
unsigned int mode=0;
unsigned int state =0;
unsigned int start=0,stop=0, valueRandom = 0;
float duty =0;
unsigned int stop_reset = 0;
unsigned int start_reset = 0;

void btn1_ngat(){
    state = 1;
    }
void btn2_ngat(){
    state = 2;
}
void btn3_ngat(){
    if((stop-start)< 4000){
        state = 2;
        valueRandom = 0;
    }
    start_reset =millis();
}
void led(float duty,unsigned r,unsigned g,unsigned b){
    unsigned R=0,G=0,B=0;
    R = duty*r;
    G = duty*g;
    B = duty*b;
    /*hien thi mau*/
    softPwmWrite(ledpin[0],R);
    softPwmWrite(ledpin[1],G);
    softPwmWrite(ledpin[2],B);
}
int main(){

    wiringPiSetup();

    /*set up GPIO*/ 
    for(int i=0;i<3;i++){
        pinMode(ledpin[i],0);
        softPwmCreate(ledpin[i],0,100);
    }
    for(int i=0;i<3;i++){
        pinMode(btn[i],1);
    }
wiringPiISR(btn1,INT_EDGE_BOTH,&btn1_ngat);
wiringPiISR(btn2,INT_EDGE_BOTH,&btn2_ngat);
wiringPiISR(btn3,INT_EDGE_BOTH,&btn3_ngat);
unsigned int count = 0;

    while(1){
        while(state==1){
            led(0.5,0,100,0); // 0.5 dong nghia voi 50%
        }
        while(state ==2){
            
            /* tang giam do sang theo chu ki*/
            /* thang do chia do sang bang 10, ma trong vong 1s (nghia la 500ms sang va 500ms toi)*/
            /* neu tu 0-2000ms thi co nghia la :0/50 -----2000/50==40 lai chia 40 ra lam 4 che do */
           if(valueRandom<=80){
                if((count>0)&&(count<=500)){
                    led(count/25,0,100,0);
                }
                if((count>500)&&(count<=1000)){
                    led(40-count/25,0,100,0);
                }
                if((count>1000)&&(count<=1500)){
                    led(count/25-20,0,100,0);
                }
                if((count>1500)&&(count<=2000)){
                    led(80-count/25,0,100,0);
           }
           }
            if(valueRandom>80){
                state = 3;
                start = millis();
                
           }
           if(count==2000){ 
            /* moi 2s random ra 1 gia tri*/
            valueRandom = rand()%80+20;
            /* in ra man hinh gia tri random*/
            printf("Gia tri ngau nhien:%d\n",valueRandom);
            fflush(stdout); // xoa bo nho dem cua he thong
            // reset 
            count=0;
           }
            count++;
           delay(1);
        }
        /* che do warning*/
        while(state==3){
            /* chop tat led do*/
            led(0,100,0,0);
            delay(125);
            led(0.5,100,0,0);
            delay(125);
            // in ra man hinh canh bao
            printf("Warning\n");
            fflush(stdout); // xoa bo nho dem cua he thong

            /* lay goc thoi gian */
            stop = millis();
            if((stop-start)>4000){
                state = 4;
            }
        }
        while(state ==4){
            /* doi mau*/
            mode++;
            if(mode>7) mode=0;
            /* hien thi mang mau chuyen doi*/
            led(0.5,mang_mau[mode][0],mang_mau[mode][1],mang_mau[mode][2]);
            delay(500);
            /* reset btn3 trong 2s*/
            if(digitalRead(btn3)==1){
                stop_reset = millis();
                if((stop_reset-start_reset)>=2000){
                    state =2;
                    valueRandom =0;
                }
                else{
                    start_reset =0;
                    stop_reset =0;
                }
            }
        }
    }
    return 0;
}