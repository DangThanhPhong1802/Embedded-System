#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<wiringPi.h>
#include<softPwm.h>
#include<time.h>


#define red 2
#define green 0
#define blue 3
#define VN (+7)


uint8_t led[3]={2,0,3};
float duty =0.1;
int hour,min;
int r,g,b;
uint8_t color[3];
time_t rawtime;
uint8_t mang_mau[10][3] ={{100,0,0},{0,100,0},{0,0,100}
                            ,{100,100,0},{0,100,100},{100,0,100}
                            ,{100,100,100},{50,0,100},{0,50,100}
                            ,{100,50,50}}; 
struct tm *info;
/* chon mau sac */
void setcolor(float duty,int r,int g,int b){
    color[0] = duty*r;
    color[1] = duty*g;
    color[2] = duty*b;
}
/* che do 2 : chuyen doi mau sac */
void chuyen_mau(int i, float duty){
    for(int j=0;j<3;j++){
        softPwmWrite(led[0],duty*mang_mau[i][0]);
        softPwmWrite(led[1],duty*mang_mau[i][1]);
        softPwmWrite(led[2],duty*mang_mau[i][2]);
    }
}
/* che do 1 : tang giam do sang */
void dosang(float duty){
    softPwmWrite(led[0],duty*color[0]);
    softPwmWrite(led[1],duty*color[1]);
    softPwmWrite(led[2],duty*color[2]);
}
/* lay gia tri random*/
int GetRandom(int min,int max){
    return min + (int)(rand()*(max-min+1.0)/(1.0+RAND_MAX));
}
void getTime(){
    time(&rawtime);
    info = gmtime(&rawtime);
}
int main(void){
    wiringPiSetup();
    getTime();
    for(int i=0;i<3;i++){
        pinMode(led[i],0);
        softPwmCreate(led[i],0,100);
    }
    printf("Thoi gian hien tai: %2d:%02d\n",(info->tm_hour+VN)%24, info->tm_min);

    while(1)
    {
    printf("do_sang r g b\n");
    scanf("%f %d %d %d",&duty,&r,&g,&b);
    setcolor(duty,r,b,g);

    /***********************************************************************************/
    printf("Nhap thoi gian OFF:\n");
    scanf("%d:%d",&hour, &min);

    while(((info->tm_hour+VN)%24!=hour)||(info->tm_min!=min))
    {
        getTime();
        printf("%d\n",info->tm_min);

          /* bat che do sang den len*/
        for(int i=0;i<3;i++){
        softPwmWrite(led[i],color[i]);
        }
        delay(2000);

         /* tang giam do sang va chuyen mau */
        for(int i=0;i<10;i++){
            for(int j=0;j<10;j++){
                getTime();
                if(((info->tm_hour+VN)%24==hour)&&(info->tm_min==min)){j=11;i=11;}
                chuyen_mau(i,j/10.0);
                duty =duty+0.1;
                if(duty>1) duty=0;
                delay(100+GetRandom(0,50));
            }
            for(int j=9;j>=0;j--){
                if(((info->tm_hour+VN)%24==hour)&&(info->tm_min==min)){j=0;i=11;}
                chuyen_mau(i,j/10.0);
                duty=duty-0.1;
                if(duty<0) duty =1;
                delay(100+GetRandom(0,50));
            }
        }
    }
    }
    return 0;
}