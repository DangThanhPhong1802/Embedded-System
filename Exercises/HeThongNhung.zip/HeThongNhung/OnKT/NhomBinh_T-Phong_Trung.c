/*Bài kiểm tra 1 
  Tên thành viên
  Đinh Văn Trung - 20146197
  Nguyễn Anh Bình - 20146097
  Đặng Thanh Phong - 20146132*/ 
  
// Khai báo thư viện 
#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
// Khai báo các chân GPIO
#define red 2 //pin 11
#define green 0 // pin13
#define blue 3 // pin15
#define bt1 22 // pin31
#define bt2 23 // pin33
#define bt3 24 // pin35
#define bt4 25 // pin37
// Tạo mảng để chứa các giá trị GPIO
uint8_t led[3]={2,0,3}; // Khởi tạo biến đèn led
uint8_t btn[3]={22,23,24}; // Khởi tạo biến nút nhấn
uint8_t r[7] ={ 100, 0   , 0  , 100  ,0   , 100   , 100};
uint8_t g[7] ={ 0  , 100 , 0  , 100  ,100 , 0     , 100};
uint8_t b[7] ={ 0  , 0   , 100, 0    ,100 , 100   , 100}; 
float count=0,count1=0,count2=0,duty;
float x,y,z;
int state =0,k;
int valueRandom;
float  duty,T,tanso;
int GetRandom(int min,int max){
    srand((unsigned int)time(NULL));
    return min + (int)(rand()*(max-min+1.0)/(1.0+RAND_MAX));
}
void interrupt_bt1(void){
    softPwmWrite(led[0], 100);
    softPwmWrite(led[1], 0);
    softPwmWrite(led[2], 0);
    printf("Nhap gia tri can tren, can duoi, tgdelay:\n");
    scanf("%f %f %f",&x,&y,&z);
    printf("Can tren %.0f,\tCan duoi %.0f,\ttgdelay %.0f\n",x,y,z);
    state=1;
}

void interrupt_bt2(void){

}


int main()
{   /* set up wiringPi*/
    wiringPiSetup();
    /* set up GPIO for led and button*/
    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }
    for(int i=0; i<2; i++){
        pinMode(btn[i],1);
    }
    /* function interrupt for button*/
    wiringPiISR(bt1, INT_EDGE_RISING, &interrupt_bt1);
    wiringPiISR(bt2, INT_EDGE_RISING, &interrupt_bt2);
while(1){
    while(state==1){
        //reset gia tri random led
        k=0;
        if(count==0){
            valueRandom = GetRandom(y,x);
            printf("Gia tri random:%d\n",valueRandom);
        }
        count++;
        delay(1);
        //xet tgdelay nhap vao
        if (count == z*1000.0){
        count=0;
        }
        if(valueRandom<=0.8*x){
            //led ngau nhien
            while(k<(int)(z*1000.0/250.0)){
            softPwmWrite(led[0], r[k]);
            softPwmWrite(led[1], g[k]);
            softPwmWrite(led[2], b[k]);
            delay(250);
            k++;
            }
        }
        if(valueRandom>0.8*x)state==2;//thoat khoi random gia tri
    }
    while(state==2){
        while(duty!=1.0){
        duty+=0,1;
        softPwmWrite(led[0], r[k]*duty);
        softPwmWrite(led[1], g[k]*duty);
        softPwmWrite(led[2], b[k]*duty);
        delay(50);
        }
        while(duty!=0.0){
        duty+=0,1;
        softPwmWrite(led[0], r[k]*duty);
        softPwmWrite(led[1], g[k]*duty);
        softPwmWrite(led[2], b[k]*duty);
        }
    }
}

return 0;
}