#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include<unistd.h>

#define red 2 //pin 11
#define green 0 // pin12
#define blue 3 // pin13
#define bt1 22 // pin29
#define bt2 23 // pin31clear
#define bt3 24 // pin33


uint8_t  led[3] = {2,0,3};
uint8_t  btn[3] = {22,23,24};
uint8_t r[10] ={ 100, 0   , 0  , 100 , 100,0   , 50 , 30   , 50 , 100};
uint8_t g[10] ={ 0  , 100 , 0  , 100 , 50 ,100 , 0  , 100  , 30 , 100};
uint8_t b[10] ={ 0  , 0   , 100, 0   , 30 ,100 , 100, 50   , 100, 100}; 
float  duty = 0.1;
uint8_t color =0;
uint8_t count =0,count1 =0;
int dosang =0;
const u_int16_t waittime = 2000;
u_int16_t currentCountValue = 0;

void interrupt_bt1(void)
{ 
    count1=0;
    dosang +=1;
    if(dosang>2)dosang=0;
    if(dosang==0){
    duty = 0.3;
    softPwmWrite(led[0], r[color]*duty);
    softPwmWrite(led[1], g[color]*duty);
    softPwmWrite(led[2], b[color]*duty);
    }
    if(dosang==1){
    duty = 0.6;
    softPwmWrite(led[0], r[color]*duty);
    softPwmWrite(led[1], g[color]*duty);
    softPwmWrite(led[2], b[color]*duty);
    }
    if(dosang==2){
    duty = 1;
    softPwmWrite(led[0], r[color]*duty);
    softPwmWrite(led[1], g[color]*duty);
    softPwmWrite(led[2], b[color]*duty);
    }
}

void interrupt_bt2(void)
{
    count += 1;
    if(count>1)count=0;
    if(count==1){
        color +=1;
        if(color>9)     color = 0;
        softPwmWrite(led[0], r[color]*duty);
        softPwmWrite(led[1], g[color]*duty);
        softPwmWrite(led[2], b[color]*duty);
    }
    if(count==0){
        for(int i=0;i<5;i++){
        softPwmWrite(led[0], 0);
        softPwmWrite(led[1], 0);
        softPwmWrite(led[2], 0);
        delay(300);
        softPwmWrite(led[0], r[color]*duty);
        softPwmWrite(led[1], g[color]*duty);
        softPwmWrite(led[2], b[color]*duty);
        delay(300);
        }
    }
}

int time()
{
    count1 ++;
    delay(1);   
    return count1;
}

int main(void)
{
    wiringPiSetup();

    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }
    for(int i=0; i<2; i++){
        pinMode(btn[i],1);
    }
    wiringPiISR(bt1, INT_EDGE_RISING, &interrupt_bt1);
    wiringPiISR(bt2, INT_EDGE_RISING, &interrupt_bt2);
    
    while(1){
        while(digitalRead(bt1)!=0){
            currentCountValue=time();
        }
    if(currentCountValue>=waittime){
        softPwmWrite(led[0], 0);
        softPwmWrite(led[1], 0);
        softPwmWrite(led[2], 0);
    }
    }

    return 0;
}