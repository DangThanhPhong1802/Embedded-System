#include<stdio.h>
#include<stdint.h>
#include<wiringPi.h>
#include<softPwm.h>
#include<stdlib.h>
#include<unistd.h>


#define reed 2 
#define green 0 
#define blue 3 

#define btn1 22 
#define btn2 23 

uint8_t ledpin[3]={2,0,3};
uint8_t btn[2]={22,23};

uint8_t mang_mau[11][3]={{100,0,0},{0,100,0},{0,0,100},{100,100,0},{100,50,0},{100,0,100},{100,0,50},{0,100,100},{0,100,50},{100,100,100}};
unsigned int state = 0;
unsigned mode = 0;
float duty = 0.1;
unsigned int start=0,stop=0;
unsigned int diff;
void btn1_ngat(){
    state =1;
    if(duty>1) duty =0;
    if(digitalRead(btn1)==1){ 
        duty = duty +0.1;
        start = millis();
        }
    while((digitalRead(btn1)==1)&&(start-stop)<=2000) {
        stop = millis();
        diff = stop-start;
    }
}
void btn2_ngat(){
    state=2;
}
void led(float duty,unsigned int r,unsigned int g,unsigned int b) {
    unsigned int R=0,G=0,B=0;
    R = duty*r;
    G = duty*g;
    B = duty*b;
    /* hien thi mau */
    softPwmWrite(ledpin[0],R);
    softPwmWrite(ledpin[1],G);
    softPwmWrite(ledpin[2],B);
}
int main(){
    /* set up wiringPi*/
    wiringPiSetup();
    /* set up GPIO */
    for(int i=0;i<3;i++){
        pinMode(ledpin[i],0);
        softPwmCreate(ledpin[i],0,100);
    }
    for(int j=0;j<2;j++){
        pinMode(btn[j],1);
    }
    /* set up interrupt*/
    wiringPiISR(btn1,INT_EDGE_BOTH,&btn1_ngat);
    wiringPiISR(btn2,INT_EDGE_BOTH,&btn2_ngat);

    unsigned int count;
    while(1){
        while(state==1){
           led(duty,mang_mau[mode][0],mang_mau[mode][1],mang_mau[mode][2]);
           delay(500);
        }
        while(state ==2){
            if(mode>10) mode=0;
            /* chuyen doi mau sac qua lai*/
            mode++;
            led(0.5,mang_mau[mode][0],mang_mau[mode][1],mang_mau[mode][2]);
            delay(500);
            /* led nhap nhay*/
            led(0,mang_mau[mode][0],mang_mau[mode][1],mang_mau[mode][2]);
            delay(200);
            led(0.5,mang_mau[mode][0],mang_mau[mode][1],mang_mau[mode][2]);
            delay(200);
        }
    }
    return 0 ;

}