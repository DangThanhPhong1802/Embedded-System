#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

#define red 0 //pin 11
#define green 1 // pin12
#define blue 2 // pin13
#define bt1 3 // pin29
#define bt2 4 // pin31
#define bt3 5 // pin33

uint8_t led[3]={0,1,2}; // Khởi tạo biến đèn led
uint8_t btn[3]={3,4,5}; // Khởi tạo biến nút nhấn

uint8_t r[10] ={ 100, 0   , 0  , 100 , 100,0   , 50 , 30   , 50 , 100};
uint8_t g[10] ={ 0  , 100 , 0  , 100 , 50 ,100 , 0  , 100  , 30 , 100};
uint8_t b[10] ={ 0  , 0   , 100, 0   , 30 ,100 , 100, 50   , 100, 100}; 
int ready=0,ready1=0,chedo;
int hour,min,sec;
float  duty,T,tanso;
uint8_t color =0;
float count;
unsigned long setTime = 0;
uint8_t valueRandom;
int timeRandom;
int ck_hour,ck_min,ck_sec;
int j,k,l,a;
int GetRandom(int min,int max){
    srand((unsigned int)time(NULL));
    return min + (int)(rand()*(max-min+1.0)/(1.0+RAND_MAX));
}
void interrupt_bt1(void)
{ 
    printf("Nhap gia tri: r g b\n");
    scanf("%d %d %d",&j,&k,&l);
    printf("r:%d\tg:%d\tb:%d\n",j,k,l);
    printf("Nhap hen gio:\n");
    scanf("%d %d",&min,&sec);
    printf("Thoi gian hen gio: %d:%d\n",min,sec);
    ready1=0;
    chedo=0;
    ready=1;
}
void interrupt_bt2(void)
{ 
    ready1=1;
    a++;
    if(a>3)a=1;
}
void interrupt_bt3(void)
{ 
    j=1;
}
int main()
{
    wiringPiSetup();
    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }
    for(int i=0; i<3; i++){
        pinMode(btn[i],1);
    }
    wiringPiISR(bt1, INT_EDGE_RISING, &interrupt_bt1);
    wiringPiISR(bt2, INT_EDGE_RISING, &interrupt_bt2);
    wiringPiISR(bt3, INT_EDGE_RISING, &interrupt_bt3);
while(1){
    softPwmWrite(led[0], 0);
    softPwmWrite(led[1], 0);
    softPwmWrite(led[2], 0);
    while(ready==1){
        setTime = min*60*1000+sec*1000;
        unsigned long currentTime = millis();
        // Chặn giá trị
        if (duty>1)duty=1;if (duty<0)duty=0;
        if (j>100)j=100;if (j<0)j=0;
        if (k>100)k=100;if (k<0)k=0;
        if (l>100)l=100;if (l<0)l=0;
        softPwmWrite(led[0], j);
        softPwmWrite(led[1], k);
        softPwmWrite(led[2], l);
    while(ready1==1){
        while(a==1){
        printf("Chon che do hoat dong:\n");
        scanf("%d",&chedo);
        printf("Chon che do: %d\n",chedo);
        a=2;
        }
        while(a==3){
        printf("Chon tan so:\n");
        scanf("%f",&tanso);
        printf("Tan so:%f",tanso);
        T = (1.0/(tanso*2.0))*1000.0;
        while(chedo==1){
            if (millis()-currentTime >= setTime){
            chedo=0;
            a=0;
            ready1=0;
            ready=0;
        }
            while(duty<1){
            duty += 0.1;
            softPwmWrite(led[0], j*duty);
            softPwmWrite(led[1], k*duty);
            softPwmWrite(led[2], l*duty);
            delay(T);
            }
            while(duty>0){
            duty -= 0.1;
            softPwmWrite(led[0], j*duty);
            softPwmWrite(led[1], k*duty);
            softPwmWrite(led[2], l*duty);
            delay(T);
            } 
        }
        while(chedo==2){
            if (millis()-currentTime >= setTime){
            chedo=0;
            a=0;
            ready1=0;
            ready=0;
        }
            valueRandom = GetRandom(0,9);
            count=0;
            if ((r[valueRandom]==j)&&(g[valueRandom]==k)&&(b[valueRandom]==l))count=T;
            while(count<T){
            softPwmWrite(led[0], r[valueRandom]);
            softPwmWrite(led[1], g[valueRandom]);
            softPwmWrite(led[2], b[valueRandom]);
            count++;
            delay(1);
            }
        }
        }
    }
    }
}
    return 0;
}