#include<stdio.h>
#include<stdint.h>
#include<softPwm.h>
#include<wiringPi.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>


#define red 2 // pin 11 
#define green 0 // pin
#define bluePin 3 
#define btn1 22 
#define btn2 23
#define btn3 24
uint8_t led[3]={2,0,3};
uint8_t btn[3]={22,23,24};
float duty =0.1;
uint8_t color=0;
int valueRandom;
uint8_t dosang;
int n;
time_t start_t, end_t;
double diff_t;
int state;
uint8_t chuyen_mau[10][3]={{100,0,0},{0,100,0},{0,0,100},
                           {100,100,0},{100,0,100},{0,100,100},
                           {100,100,100}};
void inter_btn1(){
    softPwmWrite(led[0], duty*chuyen_mau[1][0]);
    softPwmWrite(led[1], duty*chuyen_mau[1][1]);
    softPwmWrite(led[2], duty*chuyen_mau[1][2]);
}
void inter_btn2(){
   while((digitalRead(btn2)==0)) { 
   delay(50);
   n=valueRandom;
   if(n<=80){
         dosang +=1 ;
    if(dosang>2) {dosang=0;} 
    if(dosang==0){
        duty=0.2;
        softPwmWrite(led[0], duty*chuyen_mau[1][0]);
        softPwmWrite(led[1], duty*chuyen_mau[1][1]);
        softPwmWrite(led[2], duty*chuyen_mau[1][2]);
    }
    if(dosang==1){ 
        duty =0.5;
        softPwmWrite(led[0], duty*chuyen_mau[1][0]);
        softPwmWrite(led[1], duty*chuyen_mau[1][1]);
        softPwmWrite(led[2], duty*chuyen_mau[1][2]);
        }
     if(dosang==2){ 
        duty =1;
        softPwmWrite(led[0], duty*chuyen_mau[1][0]);
        softPwmWrite(led[1], duty*chuyen_mau[1][1]);
        softPwmWrite(led[2], duty*chuyen_mau[1][2]);
        }
    }
    if(n>80) { 
        duty = 0.8;
        softPwmWrite(led[0], duty*chuyen_mau[0][0]);
        softPwmWrite(led[1], duty*chuyen_mau[0][1]);
        softPwmWrite(led[2], duty*chuyen_mau[0][2]);
        delay(200);
        softPwmWrite(led[0],0);
        softPwmWrite(led[1],0);
        softPwmWrite(led[2],0);
        delay(200);     
        printf("Warning\n");
        delay(200);
}   
   } 
    }
void inter_btn3(){
    if(color==7) color =0 ;
    if(duty>1) duty =0 ;
    if(digitalRead(btn3)==1){
        time(&start_t);
        diff_t=0;}
    while((digitalRead(btn3)==1)&&(diff_t<4)){
        time(&end_t);
        diff_t = difftime(end_t, start_t);
        duty=0.5;
        printf("Thời gian thực thi = %.2f\n", diff_t);
        softPwmWrite(led[0], duty*chuyen_mau[1][0]);
        softPwmWrite(led[1], duty*chuyen_mau[1][1]);
        softPwmWrite(led[2], duty*chuyen_mau[1][2]);}
    while((digitalRead(btn3)!=1)&&(diff_t>=4)){
        color = color +1 ;
        softPwmWrite(led[0], duty*chuyen_mau[color][0]);
        softPwmWrite(led[1], duty*chuyen_mau[color][1]);
        softPwmWrite(led[2], duty*chuyen_mau[color][2]);
    } 
      
}

int GetRandom(int min,int max){
    return min + (int)(rand()*(max-min+1.0)/(1.0+RAND_MAX));
}
int main(void){
    wiringPiSetup();
    // set up GPIO for led and button
    for(int i=0;i<3;i++){
        pinMode(led[i],0);
        softPwmCreate(led[i],0,100);
    }
    for(int i=0;i<3;i++){
        pinMode(btn[i],1);
    }
    /*interrupt nut bam */
    wiringPiISR(btn1,INT_EDGE_BOTH,&inter_btn1);
    wiringPiISR(btn2,INT_EDGE_BOTH,&inter_btn2);
    wiringPiISR(btn3,INT_EDGE_BOTH,&inter_btn3);
    while(1){    
        valueRandom = GetRandom(20,100);
        printf("%d\n",valueRandom);
        delay(2000);
    }

    return 0;
}