#include<stdio.h>
#include<wiringPi.h>
#include<stdint.h>
#include<softPwm.h>
#include<stdlib.h>


#define redPin 2 
#define greenPin 0
#define bluePin 3 
#define btn1 22
#define btn2 23

uint8_t led[3]={2,0,3};
uint8_t btn[2]={22,23};
uint8_t color =0;
float duty =0.1;
uint8_t count = 0;
uint8_t count1 =0;
int dosang =0;

uint8_t r[10] ={ 100, 0   , 0  , 100 , 100,0   , 50 , 30   , 50 , 100};
uint8_t g[10] ={ 0  , 100 , 0  , 100 , 50 ,100 , 0  , 100  , 30 , 100};
uint8_t b[10] ={ 0  , 0   , 100, 0   , 30 ,100 , 100, 50   , 100, 100}; 

void interrupt_bt1(void){
    count1 =0;
    dosang +=1;
    if(dosang>2) {dosang =0;}
    if(dosang ==0){
        duty=0.3;
        softPwmWrite(led[0],duty*r[color]);
        softPwmWrite(led[1],duty*g[color]);
        softPwmWrite(led[2],duty*b[color]);
    } 
    if(dosang ==1){
        duty=0.6;
        softPwmWrite(led[0],duty*r[color]);
        softPwmWrite(led[1],duty*g[color]);
        softPwmWrite(led[2],duty*b[color]);
    } 
    if(dosang ==2){
        duty=1;
        softPwmWrite(led[0],duty*r[color]);
        softPwmWrite(led[1],duty*g[color]);
        softPwmWrite(led[2],duty*b[color]);
    } 
}
void interrupt_bt2(void){

}
int main(){
    // set up wiringpi
    wiringPiSetup();
    // led
    for(int i=0;i<3;i++){
        pinMode(led[i],0);
        softPwmCreate(led[i],0,100);
    }
    // button
    for(int i=0;i<2;i++){
        pinMode(btn[i],1);
    }
    wiringPiISR(btn1,INT_EDGE_RISING,&interrupt_bt1);
    return 0;
}