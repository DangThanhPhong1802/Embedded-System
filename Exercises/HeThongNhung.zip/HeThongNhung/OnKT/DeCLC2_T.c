#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

#define red 2 //pin 11
#define green 0 // pin12
#define blue 3 // pin13
#define bt1 22 // pin29
#define bt2 23 // pin31
#define bt3 24 // pin33
uint8_t  led[3] = {2,0,3};
uint8_t  btn[3] = {22,23,24};
uint8_t r[10] ={ 100, 0   , 0  , 100 , 100,0   , 50 , 30   , 50 , 100};
uint8_t g[10] ={ 0  , 100 , 0  , 100 , 50 ,100 , 0  , 100  , 30 , 100};
uint8_t b[10] ={ 0  , 0   , 100, 0   , 30 ,100 , 100, 50   , 100, 100}; 
float  duty;
uint8_t color =0;
float count =3001;
u_int8_t valueRandom;
int timeRandom;
int ck_hour,ck_min,ck_sec;
int j,k,l;
int GetRandom(int min,int max){
    return min + (int)(rand()*(max-min+1.0)/(1.0+RAND_MAX));
}
int main()
{
    wiringPiSetup();
    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }
    for(int i=0; i<2; i++){
        pinMode(btn[i],1);
    }
    time_t current_time;
    char time_string[9];
    int hour,min,sec;
    struct tm * time_info;
    while(1){
        // Lấy thời gian hiện tại
        time(&current_time);
        time_info = localtime(&current_time);
        // Chuyển đổi thời gian thành chuỗi
        strftime(time_string, sizeof(time_string), "%H:%M:%S", time_info);
        // Lấy giờ hiện tại
        hour = time_info->tm_hour;
        min = time_info->tm_min;
        sec = time_info->tm_sec;
        printf("%d:%d:%d\n",hour,min,sec);
        // Random màu
        valueRandom = rand()%10+0;
        // Random time tắt đèn
        timeRandom = GetRandom(2000,3000);
        printf("%d\n",timeRandom);
        // Đk time off
        if((hour==ck_hour)&(min==ck_min)&(sec>=ck_sec))count=3001;
        // Đk chạy lại
        while(count==3001){
            printf("Nhap offtime:\n");
            scanf("%d %d %d",&ck_hour,&ck_min,&ck_sec);
            printf("thoi gian ngung la:%d:%d:%d\n",ck_hour,ck_min,ck_sec);
            printf("Nhap gia tri: dosang r g b\n");
            scanf("%f %d %d %d",&duty,&j,&k,&l);
            // Chặn giá trị
            if (duty>1)duty=1;if (duty<0)duty=0;
            if (j>100)j=100;if (j<0)j=0;
            if (k>100)k=100;if (k<0)k=0;
            if (l>100)l=100;if (l<0)l=0;
            printf("dosang: %.2f\tr:%d\tg:%d\tb:%d\n",duty,j,k,l);
            // Tắt dần
            while(count<timeRandom){
            count++;
            delay(1);
            duty = 1 - 0.1*(count/200);
            softPwmWrite(led[0], j*duty);
            softPwmWrite(led[1], k*duty);
            softPwmWrite(led[2], l*duty);
            }
            count = 0;  //Thoat khoi vong lap
        }
        count = 0;  //Set giá trị để duy trì
        while(count<timeRandom){
        count++;
        delay(1);
        duty = 1 - 0.1*(count/200);
        softPwmWrite(led[0], r[valueRandom]*duty);
        softPwmWrite(led[1], g[valueRandom]*duty);
        softPwmWrite(led[2], b[valueRandom]*duty);
        }
        
    }
    return 0;
}