#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

#define red 2 //pin 11
#define green 0 // pin12
#define blue 3 // pin13
#define bt1 22 // pin29
#define bt2 23 // pin31
#define bt3 24 // pin33

uint8_t  led[3] = {2,0,3};
uint8_t  btn[3] = {22,23,24};
uint8_t r[10] ={ 100, 0   , 0  , 100 ,0   ,  100 , 100};
uint8_t g[10] ={ 0  , 100 , 0  , 100 ,100 ,  0   , 100};
uint8_t b[10] ={ 0  , 0   , 100, 0   ,100 ,  100 , 100}; 
float  duty=0;
uint8_t color =0;
float count =0,count1=0;
uint8_t valueRandom;
uint8_t ledRandom;
int timeRandom;
int ck_hour,ck_min,ck_sec;
int j=0,k=0,l=0;
int state=0 ;
time_t start_t, end_t;
double diff_t;

int GetRandom(int min,int max){
    srand((unsigned int)time(NULL));
    return min + (int)(rand()*(max-min+1.0)/(1.0+RAND_MAX));
}
int demtime()
{
    count1 ++;
    delay(1);   
    return count1;
}
void interrupt_bt1(void)
{ 
    softPwmWrite(led[0], 0);
    softPwmWrite(led[1], 50);
    softPwmWrite(led[2], 0);
}
void interrupt_bt2(void)
{ 
    j=1;
}
void interrupt_bt3(void)
{
    while(j==2){
    l=9;
    time(&end_t);
    diff_t = difftime(end_t, start_t);
    if(diff_t<4){
        j=0;
        count=0;
        count1=0;
        l=0;
        printf("Da Reset\n");
        softPwmWrite(led[0], 0);
        softPwmWrite(led[1], 0);
        softPwmWrite(led[2], 0);
    }
    else{
    if(digitalRead(bt3)==1){time(&start_t);diff_t=0;}
    while((digitalRead(bt3)==1)&&(diff_t<2)){
        time(&end_t);
        diff_t = difftime(end_t, start_t);
    if(diff_t>=2){
        l=0;
        j=0;
        count=0;
        count1=0;
        printf("Da Reset\n");
        softPwmWrite(led[0], 0);
        softPwmWrite(led[1], 0);
        softPwmWrite(led[2], 0);
        } 
        }
    }
    }
}
int main(void)
{
    wiringPiSetup();

    for(int i=0; i<3; i++){
        pinMode(led[i],0);
        softPwmCreate(led[i], 0, 100);
    }
    for(int i=0; i<3; i++){
        pinMode(btn[i],1);
    }
    wiringPiISR(bt1, INT_EDGE_RISING, &interrupt_bt1);
    wiringPiISR(bt2, INT_EDGE_RISING, &interrupt_bt2);
    wiringPiISR(bt3, INT_EDGE_RISING, &interrupt_bt3);
    while(1){
        while(j==1){
            if(count==0){
            valueRandom = GetRandom(20,100);
            printf("%d\n",valueRandom);
            }
            if(valueRandom<=80){
                while(duty!=100){
                duty += 10;
                softPwmWrite(led[0], 0);
                softPwmWrite(led[1], duty);
                softPwmWrite(led[2], 0);
                delay(100);
                }
                while(duty!=0){
                duty -= 10;
                softPwmWrite(led[0], 0);
                softPwmWrite(led[1], duty);
                softPwmWrite(led[2], 0);
                delay(100);
                count=0;
                }
            }
            if(valueRandom>80){
                printf("Warning\n");
                time(&start_t);
                diff_t=0;
                j=2;
                count=1;
            }
        while(j==2){
            while(l<8){
                l++;
                softPwmWrite(led[0], 80);
                softPwmWrite(led[1], 0);
                softPwmWrite(led[2], 0);
                delay(250);
                softPwmWrite(led[0], 0);
                softPwmWrite(led[1], 0);
                softPwmWrite(led[2], 0);
                delay(250);
            }
            ledRandom = GetRandom(0,6);
            softPwmWrite(led[0], r[ledRandom]*1);
            softPwmWrite(led[1], g[ledRandom]*1);
            softPwmWrite(led[2], b[ledRandom]*1);
            delay(1000);
        }
        }
    }
    return 0;
}