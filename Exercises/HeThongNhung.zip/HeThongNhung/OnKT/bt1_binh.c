#include<stdio.h>
#include<wiringPi.h>
#include<stdint.h>
#include<softPwm.h>
/*Viết code để các đèn led R,G,B lần lượt sáng dần rồi tối dần. Thời gian sáng dần và tối dần là 2s.*/
uint8_t led[3] = {2,0,3}; 
int main()
{
    wiringPiSetup();
    // khai bao IO 
    for(int i=0;i<3;i++) 
    {
        pinMode(led[i],OUTPUT);
        softPwmCreate(led[i],0,100);

    }
    while(1)
    {
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<21;j++) 
            {   softPwmWrite(led[i],j*5); // xung la 100 neu chia 20% la 5 
                delay(100);
            }
            for(int j=19;j>=0;j--)
            {
                softPwmWrite(led[i],j*5);
                delay(100);
            }
        }
    }
    return 0;
}
