#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

u_int8_t timeRandom;
int main() {
    wiringPiSetup();
    time_t current_time;
    struct tm * time_info;
    char time_string[9];
    int hour,min,sec;
    while(1){
    // Lấy thời gian hiện tại
    time(&current_time);
    time_info = localtime(&current_time);

    // Chuyển đổi thời gian thành chuỗi
    strftime(time_string, sizeof(time_string), "%H:%M:%S", time_info);
    
    // Lấy giờ hiện tại
    hour = time_info->tm_hour;
    min = time_info->tm_min;
    sec = time_info->tm_sec;
    // Kiểm tra điều kiện
    
    timeRandom = rand()%1000;
    printf("%d\n",timeRandom);
    delay(1000);
    }
    return 0;
}





