#include "ros/ros.h"
#include "my_robot/Twist.h"
#include <stdio.h>
#include <wiringPi.h>
#include <stdint.h>
#include <wiringPiSPI.h>
#include <sstream>

#define Stop 24
#define Start 23
#define spi0 0

uint8_t data_X[3];
uint8_t data_Y[3];
uint8_t state = 0;
float x = 0;
float y = 0;

uint16_t X;
uint16_t Y;

void checkStart(){state=1;}
void checkStop(){state=0;}


void mainControl(void)
{
    wiringPiSetup();
    wiringPiSPISetup(spi0, 1000000);
    wiringPiISR(Start,INT_EDGE_RISING, &checkStart);
    wiringPiISR(Stop,INT_EDGE_RISING, &checkStop);
}

void channelX()
{
    data_X[0] = 0x01;
    data_X[1] = 0xA0;
    data_X[2] = 0x00;
    wiringPiSPIDataRW(spi0, data_X, 3);
}
void channelY()
{
    data_Y[0] = 0x01;
    data_Y[1] = 0xE0;
    data_Y[2] = 0x00;
    wiringPiSPIDataRW(spi0, data_Y, 3);
}



void joystick()
{
  channelX();
  X = (uint16_t)data_X[1] << 8 | data_X[2];
  delay(10);
  channelY();
  Y = (uint16_t)data_Y[1] << 8 | data_Y[2];
  delay(10);
  if((Y>1500)&&(Y<2500)) x = 0;
  if(Y<1500) x =  -0.2*state;
  if(Y>2500) x =  0.2*state;
  if((X>1500)&&(X<2500)) y = 0;
  if(X<1500) y = -0.3*state;
  if(X>2500) y = 0.3*state;
}


int main(int argc, char **argv)
{
  mainControl();

  ros::init(argc, argv, "talker");

  ros::NodeHandle n;

  ros::Publisher chatter_pub = n.advertise<my_robot::Twist>("/cmd_vel", 1000);
  ros::Rate loop_rate(10);

  while (ros::ok())
  {

    my_robot::Twist msg1;

    joystick();
    
    msg1.linear.x = x;
    msg1.angular.z = y;

    chatter_pub.publish(msg1);


    ros::spinOnce();



    loop_rate.sleep();

  }


  return 0;
}
